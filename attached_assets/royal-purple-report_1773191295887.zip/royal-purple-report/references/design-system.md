# Design System Reference

> **Brand Authority**: This report inherits core brand rules from the
> **matrix-brand-guide** skill. For Matrix/Throttle master specs, logo
> files, typography weights and editorial standards, refer to the brand
> guide. The Royal Purple palette below overrides Matrix colors for report
> body content only — Throttle branding on footer/cover/closing still uses
> Matrix brand colors per the brand guide.

## Color Palette

```javascript
const C = {
  purple:      "4B2D8A",   // Primary — backgrounds, headers, tables
  purpleMid:   "6B44B8",   // Secondary — chart series, card headers
  purpleLight: "9B6FD4",   // Tertiary — chart series, accents
  gold:        "C8973A",   // Primary accent — numbers, highlights
  goldLight:   "E8B85A",   // Light gold — secondary callouts
  white:       "FFFFFF",
  offWhite:    "F8F5FF",   // Slide background (purple tint)
  midGray:     "94A3B8",   // Secondary text
  darkGray:    "334155",   // Body text
  dark:        "1E1035",   // Cover/divider backgrounds
  teal:        "0D9488",   // 4th next-steps card
};
```

**NEVER use `#` prefix on any hex color. PptxGenJS does not accept it.**

---

## Logo Placement

All logos are stored in `assets/` and referenced via `SKILL_ASSETS` constant.

### Royal Purple Logo (Content Slide Headers)
```javascript
// Compact logo (no checkered flag) — top-right of purple header bar
// Aspect ratio ~4:1 → h=0.38, w=1.55
slide.addImage({ path: RP_LOGO, x: 8.2, y: 0.08, h: 0.38, w: 1.55,
  sizing: { type: "contain", w: 1.55, h: 0.38 } });
```

### Royal Purple Full Logo (Cover Slide)
```javascript
// Full logo with checkered flag — top-left of cover
// Aspect ratio ~3.4:1 → h=0.60, w=2.05
slide.addImage({ path: RP_LOGO_FULL, x: 0.8, y: 0.5, h: 0.60, w: 2.05,
  sizing: { type: "contain", w: 2.05, h: 0.60 } });
```

### Throttle Logo (Footer)
```javascript
// White wordmark in every footer bar
// Actual image: 600×62 px → aspect ratio 9.68:1
// Bounding box: h=0.16, w=1.55
slide.addImage({ path: THROTTLE_WHITE, x: 0.3, y: 5.375, h: 0.16, w: 1.55,
  sizing: { type: "contain", w: 1.55, h: 0.16 } });
```

### Throttle Logo (Cover / Closing)
```javascript
// Larger white wordmark above footer on dark slides
// Actual image: 600×62 px → aspect ratio 9.68:1
// Bounding box: h=0.22, w=2.13
slide.addImage({ path: THROTTLE_WHITE, x: 0.8, y: 4.55, h: 0.22, w: 2.13,
  sizing: { type: "contain", w: 2.13, h: 0.22 } });
```

---

## Slide Background

- **Content slides**: `slide.background = { color: C.offWhite }` — "F8F5FF"
- **Cover slide**: `slide.background = { color: C.dark }` — "1E1035"
- **Section dividers**: `slide.background = { color: C.dark }` — "1E1035"

---

## Recurring Header Component

Every content slide (slides 2–18) uses this header pattern:

```javascript
function addSlideHeader(slide, title, subtitle) {
  // Purple top bar
  slide.addShape("rect", { x: 0, y: 0, w: 10, h: 0.55,
    fill: { color: "4B2D8A" }, line: { type: "none" } });
  // Gold vertical accent left of title
  slide.addShape("rect", { x: 0.45, y: 0.7, w: 0.07, h: 0.55,
    fill: { color: "C8973A" }, line: { type: "none" } });
  // Title text
  slide.addText(title, { x: 0.6, y: 0.68, w: 9.0, h: 0.6,
    fontSize: 22, bold: true, color: "1E1035", fontFace: "Calibri", valign: "middle", margin: 0 });
  // Subtitle text
  if (subtitle) {
    slide.addText(subtitle, { x: 0.6, y: 1.22, w: 9.0, h: 0.3,
      fontSize: 11, color: "94A3B8", fontFace: "Calibri", valign: "top", margin: 0 });
  }
  // "ROYAL PURPLE" branding top-right
  slide.addText("ROYAL PURPLE", { x: 6.5, y: 0.08, w: 3.3, h: 0.38,
    fontSize: 13, bold: true, color: "C8973A", fontFace: "Calibri",
    align: "right", valign: "middle", charSpacing: 2 });
}
```

---

## Footer Component

Every slide (including cover and dividers) uses this footer:

```javascript
function addFooter(slide, pageNum, totalSlides) {
  slide.addShape("rect", { x: 0, y: 5.35, w: 10, h: 0.275,
    fill: { color: "4B2D8A" }, line: { type: "none" } });
  // Throttle logo — 9.68:1 aspect ratio
  slide.addImage({ path: THROTTLE_WHITE, x: 0.3, y: 5.375, h: 0.16, w: 1.55,
    sizing: { type: "contain", w: 1.55, h: 0.16 } });
  slide.addText(
    "CONFIDENTIAL  |  Royal Purple Installer Program Pilot  |  [Month Year]",
    { x: 1.95, y: 5.36, w: 6.35, h: 0.24, fontSize: 8,
      color: "E8B85A", fontFace: "Calibri", valign: "middle" }
  );
  slide.addText(`${pageNum} / ${totalSlides}`, {
    x: 8.8, y: 5.36, w: 1, h: 0.24, fontSize: 8,
    color: "FFFFFF", fontFace: "Calibri", align: "right", valign: "middle"
  });
}
```

---

## Stat Card Component

Used on executive summary, revenue overview, and all store deep-dive slides.

```javascript
function statCard(slide, x, y, w, h, label, value, subLabel) {
  // White card with shadow
  slide.addShape("rect", { x, y, w, h,
    fill: { color: "FFFFFF" },
    line: { color: "E2E2F0", width: 0.5 },
    shadow: { type: "outer", blur: 8, offset: 2, angle: 135,
              color: "000000", opacity: 0.08 }
  });
  // Gold top stripe
  slide.addShape("rect", { x, y, w, h: 0.06,
    fill: { color: "C8973A" }, line: { type: "none" }
  });
  // Value — adaptive font size to prevent overflow
  const valFontSize = value.length > 8 ? 20 : 26;
  slide.addText(value, {
    x: x + 0.1, y: y + 0.18, w: w - 0.2, h: 0.55,
    fontSize: valFontSize, bold: true, color: "4B2D8A",
    fontFace: "Calibri", align: "center", shrinkText: true
  });
  // Label
  slide.addText(label, {
    x: x + 0.1, y: y + 0.72, w: w - 0.2, h: 0.25,
    fontSize: 9, bold: true, color: "334155",
    fontFace: "Calibri", align: "center", charSpacing: 1
  });
  // Sub-label
  if (subLabel) {
    slide.addText(subLabel, {
      x: x + 0.1, y: y + 0.95, w: w - 0.2, h: 0.2,
      fontSize: 8, color: "94A3B8", fontFace: "Calibri", align: "center"
    });
  }
}
```

**Standard 4-card row layout** (executive summary, store deep dives):
- Card 1: `x: 0.45, y: 1.55, w: 2.1, h: 1.22`
- Card 2: `x: 2.75, y: 1.55, w: 2.1, h: 1.22`
- Card 3: `x: 5.05, y: 1.55, w: 2.1, h: 1.22`
- Card 4: `x: 7.35, y: 1.55, w: 2.1, h: 1.22`

---

## Chart Styles

Always apply these options for a modern, clean look:

```javascript
const chartBase = {
  chartArea: { fill: { color: "F8F5FF" } },
  catAxisLabelColor: "334155",
  valAxisLabelColor: "334155",
  valGridLine: { color: "E0D8F0", size: 0.5 },
  catGridLine: { style: "none" },
  dataLabelColor: "334155",
  dataLabelFontSize: 8,
  dataLabelFormatCode: '$#,##0',   // always prefix revenue data labels with $
  valAxisFormatCode: '$#,##0',     // always prefix value axis with $
  catAxisFontSize: 8,
  valAxisFontSize: 8,
};
```

**Standard color series** (use in order):
```javascript
const seriesColors = [
  "4B2D8A",  // purple
  "6B44B8",  // purpleMid
  "C8973A",  // gold
  "E8B85A",  // goldLight
  "9B6FD4",  // purpleLight
  "B0A0D8",  // light purple
  "7855B0",  // deep mid
  "94A3B8",  // gray
];
```

---

## Store Ranking Table

Column widths for the 6-column ranking table:
```javascript
colW: [0.55, 2.6, 1.5, 0.9, 1.2, 2.35]
// Rank | Store Name | Revenue | Invoices | Avg Rev/Inv | Top Product
```

Header row: purple background (`4B2D8A`), white text, gold for "Rank" column.
Alternating rows: white (`FFFFFF`) / light purple (`F2EEF8`).
Rank 1–3 get gold/silver/bronze colored rank numbers.

---

## Store Performance Matrix (Slide 7)

Four-column infographic row layout. **Critical: each column occupies a
fixed horizontal zone with a gutter between AVG TICKET and REVENUE to
prevent label overlap.**

```
Zone          x-start   x-end    width   Content
──────────    ───────   ──────   ─────   ────────────────────────────
STORE         0.45      2.55     2.10    Store name text
VOLUME        2.60      6.45     3.85    Purple bar + invoice count label
AVG TICKET    6.55      8.15     1.60    Gold bar + dollar label (right-aligned)
  (gutter)    8.15      8.25     0.10    Empty — prevents collision
REVENUE       8.25      9.55     1.30    Right-aligned revenue text (e.g. "$571.4K")
```

**Column constants:**
```javascript
const VOL_BAR_X = 2.60, VOL_BAR_W = 3.80;
const TKT_BAR_X = 6.55, TKT_BAR_W = 1.60;
const TKT_RIGHT_EDGE = 8.15;    // hard boundary — nothing past here
const REV_COL_X = 8.25, REV_COL_W = 1.30;
```

**Avg ticket label rule:**
Always place the dollar label inside a fixed-width text box (w: 0.60)
right-aligned to `TKT_RIGHT_EDGE` (8.15"). This guarantees the label
sits at a predictable position regardless of bar length. Use white text
when the bar fill covers >55% of `TKT_BAR_W`, otherwise use `darkGray`.

```javascript
slide.addText(fmt(s.avgRev), {
  x: TKT_RIGHT_EDGE - 0.60, y: ry, w: 0.60, h: ROW_H,
  fontSize: 8, bold: isHighTkt,
  color: tktBarFill >= (TKT_BAR_W * 0.55) ? "FFFFFF" : "334155",
  fontFace: "Calibri", align: "right", valign: "middle"
});
```

**Revenue column** is a separate `addText` call, never part of the bar rendering:
```javascript
slide.addText(fmtK(s.revenue), {
  x: REV_COL_X, y: ry, w: REV_COL_W, h: ROW_H,
  fontSize: 8.5, bold: isTop3, color: isTop3 ? "4B2D8A" : "334155",
  fontFace: "Calibri", align: "right", valign: "middle"
});
```

---

## Insights / Narrative Box

Used on executive summary slide (slides 3 and 4):

```javascript
// Purple box
slide.addShape("rect", { x: 0.45, y: 3.0, w: 5.8, h: 1.9,
  fill: { color: "4B2D8A" }, line: { type: "none" } });
// Section label
slide.addText("Pilot Highlights", { x: 0.6, y: 3.08, w: 5.5, h: 0.3,
  fontSize: 10, bold: true, color: "C8973A", fontFace: "Calibri", charSpacing: 2 });
// Bullet content
slide.addText(bulletText, { x: 0.6, y: 3.42, w: 5.5, h: 1.35,
  fontSize: 10, color: "FFFFFF", fontFace: "Calibri", valign: "top" });
```

Bullet format: use `"• "` prefix in plain text strings (not pptxgenjs `bullet: true`).

---

## Store Deep Dive Layout

Full deep-dive slide (one of the top 5 stores):

```
y=0.00  Purple top bar (h=0.55)
y=0.68  Title: "Store Deep Dive: [Store Name]"
y=1.22  Subtitle: "Rank #N of 12 by Revenue | [Month Year]"
y=1.55  4 stat cards (w=2.1, h=1.22 each)
y=2.95  Left: Product SKU bar chart (w=5.4, h=2.3)
y=2.95  Right: Location Notes box (w=3.4, h=2.3) — purple bg
y=5.35  Footer
```

Notes box content:
- Gold section label "Location Notes"
- White body text (9.5pt) with store narrative
- Gold bottom line: "Top Product: [code] ([category])"

---

## Compact Store Snapshot Layout

Two stores per slide:

```
Left panel:  x=0.45, y=1.55, w=4.4
Right panel: x=5.20, y=1.55, w=4.4

Each panel:
  - Gold top stripe (h=0.06)
  - Purple header bar (h=0.50) with rank + store name
  - 3 mini stat boxes (revenue, invoices, avg/invoice)
  - Location Notes text block
  - Volume progress bar at bottom
```

Volume bar: gray background `E8E0F0`, purple fill scaled by `invoices/maxInvoices`.

---

## Section Divider Slide

```javascript
slide.background = { color: "1E1035" };
// Diagonal purple swoosh shapes
slide.addShape("rect", { x: -0.3, y: 2.2, w: 10.6, h: 1.8,
  fill: { color: "4B2D8A" }, rotate: -2 });
// Gold left border
slide.addShape("rect", { x: 0, y: 0, w: 0.12, h: 5.625,
  fill: { color: "C8973A" } });
// Large section number (background)
slide.addText("05", { x: 0.3, y: 0.5, w: 2, h: 1.2,
  fontSize: 80, bold: true, color: "2A1A5E" });
// Section title lines
slide.addText("STORE-LEVEL", { fontSize: 32, bold: true, color: "FFFFFF", charSpacing: 4 });
slide.addText("DEEP DIVES",  { fontSize: 32, bold: true, color: "C8973A", charSpacing: 4 });
```

---

## Cover Slide

```javascript
slide.background = { color: "1E1035" };
// Two diagonal purple shapes (bottom half)
// Gold vertical bar left
// "ROYAL PURPLE" in gold (spaced caps)
// "Installer Program" large white bold
// "Monthly Performance Report" gold
// Divider line
// Date / location sub-lines in gray
// Footer bar (no page number on cover)
```
