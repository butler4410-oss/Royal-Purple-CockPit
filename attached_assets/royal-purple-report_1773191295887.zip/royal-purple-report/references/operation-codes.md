# Operation Code Reference — Duke of Oil POS System

> **Purpose:** Classifies every known operation code from the Duke of Oil
> point-of-sale system into Royal Purple vs non-Royal Purple categories.
> Use this reference whenever the Excel export contains ALL operation codes
> (not just Royal Purple-filtered data) to calculate RP penetration rate,
> competitor brand share, and conversion opportunity.

## How Invoice-Level Data Works

Each invoice (oil change visit) generates **multiple rows** in the export —
one row per operation code on that invoice. All rows for the same invoice
share the same `Invoice #`, `Total Rev`, and `Total Rev/Inv` values. The
revenue is the **total invoice amount** (not per line item).

**Critical:** To avoid double-counting revenue, always group by `Invoice #`
first and take the revenue value once per invoice.

### Identifying the Oil Product on an Invoice

Each invoice contains a mix of codes: one **oil product code**, one or more
**spec flags** (GF6, DEXOS1), one **service tier code** (S1–S6, B7–B10, CK),
one **oil filter**, and optionally air filters, cabin filters, wipers, or
air fresheners. The oil product code is the one that determines which brand
was used.

---

## Code Classification

### Royal Purple Oil (`rp_oil`)

These codes indicate the customer received Royal Purple motor oil.

| Code | Sub-brand | Full Name |
|------|-----------|-----------|
| `RS0W20` | RS Series | Royal Purple High Performance 0W-20 |
| `RS5W20` | RS Series | Royal Purple High Performance 5W-20 |
| `RS5W30` | RS Series | Royal Purple High Performance 5W-30 |
| `RS5W40` | RS Series | Royal Purple High Performance 5W-40 |
| `RS0W16` | RS Series | Royal Purple 0W-16 |
| `RS0W40` | RS Series | Royal Purple Advanced 0W-40 |
| `HMX0W20` | HMX Series | Royal Purple High Mileage 0W-20 |
| `HMX5W20` | HMX Series | Royal Purple High Mileage 5W-20 |
| `HMX5W30` | HMX Series | Royal Purple High Mileage 5W-30 |
| `RMS5W30` | HMX Series | Royal Purple High Mileage Synthetic 5W-30 |
| `RMS5W20` | HMX Series | Royal Purple High Mileage Synthetic 5W-20 |
| `RSD5W40` | Duralec | Royal Purple Duralec Diesel 5W-40 |
| `RSD15W40` | Duralec | Royal Purple Duralec Diesel 15W-40 |
| `11722` | Generic RP | Royal Purple (unspecified formulation) |
| `RP0W20` | RP Synthetic | Royal Purple Synthetic 0W-20 |
| `RP5W30` | RP Synthetic | Royal Purple Synthetic 5W-30 |
| `RP5W20` | RP Synthetic | Royal Purple Synthetic 5W-20 |
| `RP0W16` | RP Synthetic | Royal Purple 0W-16 |
| `RP5W40` | RP Synthetic | Royal Purple European Synthetic 5W-40 |
| `RP0W40` | RP Synthetic | Royal Purple 0W-40 |

**Prefix rules for new/unknown codes:**
- `RS*` → RS Series (Royal Purple High Performance)
- `HMX*` → HMX Series (Royal Purple High Mileage)
- `RMS*` → HMX Series (Royal Purple High Mileage Synthetic)
- `RSD*` → Duralec (Royal Purple Diesel)
- `RP*` → RP Synthetic (generic Royal Purple)
- `11722` → Generic RP (no viscosity/formulation specified)

### Royal Purple Additives (`rp_additive`)

| Code | Product |
|------|---------|
| `18000` | Royal Purple Max-Atomizer fuel treatment |
| `11755` | Royal Purple Max-Tane diesel treatment |

### Competitor Oil (`competitor_oil`)

| Code | Brand | Sub-brand | Full Name |
|------|-------|-----------|-----------|
| `S5W30` | CAM2 | Synthetic | Full Synthetic CAM2 5W-30 |
| `S5W20` | CAM2 | Synthetic | Full Synthetic CAM2 5W-20 |
| `S0W20` | CAM2 | Synthetic | Full Synthetic CAM2 0W-20 |
| `5W30` | CAM2 | Conventional | CAM2 Conventional 5W-30 |
| `5W20` | CAM2 | Conventional | CAM2 Conventional 5W-20 |
| `VS0W20` | Valvoline | Full Synthetic | Valvoline Full Synthetic 0W-20 |
| `VS5W30` | Valvoline | Full Synthetic | Valvoline Full Synthetic 5W-30 |
| `VS5W20` | Valvoline | Full Synthetic | Valvoline Full Synthetic 5W-20 |
| `VS0W16` | Valvoline | Full Synthetic | Valvoline Full Synthetic 0W-16 |
| `VM5W20` | Valvoline | MaxLife | Valvoline MaxLife 5W-20 |
| `VM5W30` | Valvoline | MaxLife | Valvoline MaxLife 5W-30 |
| `VM0W20` | Valvoline | MaxLife | Valvoline MaxLife 0W-20 |
| `V5W20` | Valvoline | Conventional | Valvoline Conventional 5W-20 |
| `VB5W30` | Valvoline | Conventional | Valvoline Conventional 5W-30 |
| `V10W30` | Valvoline | Conventional | Valvoline Conventional 10W-30 |
| `VE5W30` | Valvoline | Conventional | Valvoline 5W-30 |
| `M5W20` | Mobil 1 | Synthetic | Mobil 1 Synthetic 5W-20 |
| `M5W30` | Mobil 1 | Synthetic | Mobil 1 Synthetic 5W-30 |
| `M0W20` | Mobil 1 | Synthetic | Mobil 1 0W-20 Synthetic |
| `M0W20D` | Mobil 1 | Synthetic | Mobil 1 Super Car 0W-20 |
| `M0W16` | Mobil 1 | Synthetic | Mobil 1 0W-16 Synthetic |
| `M5W40` | Mobil 1 | Synthetic | Mobil 1 Turbo Diesel Truck 5W-40 |
| `CS0W20` | Castrol | Edge | Castrol Edge 0W-20 |
| `CS5W30` | Castrol | Edge | Castrol Edge 5W-30 |
| `CS5W20` | Castrol | Edge | Castrol Edge 5W-20 |
| `CS5W40` | Castrol | Edge | Castrol Edge 5W-40 |
| `PS5W20` | Pennzoil | Platinum | Pennzoil Platinum Synthetic 5W-20 |
| `PS5W30` | Pennzoil | Platinum | Pennzoil Platinum Synthetic 5W-30 |
| `PU0W40` | Pennzoil | Ultra | Pennzoil Ultra Synthetic 0W-40 |
| `PB5W20` | Pennzoil | Conventional | Pennzoil Conventional 5W-20 |

**Prefix rules for new/unknown competitor codes:**
- `S*` + viscosity → CAM2 Synthetic (e.g., `S0W16`)
- `VS*` → Valvoline Full Synthetic
- `VM*` → Valvoline MaxLife (High Mileage)
- `V*` + viscosity → Valvoline Conventional
- `M*` + viscosity → Mobil 1
- `CS*` → Castrol Edge
- `PS*` → Pennzoil Platinum Synthetic
- `PU*` → Pennzoil Ultra
- `PB*` → Pennzoil Conventional
- Bare viscosity (e.g., `5W30`, `5W20`) → CAM2 Conventional

### Oil Specification Flags (`spec_flag`)

These appear on nearly every invoice and indicate the vehicle's oil
specification requirement. **They are NOT separate products.** Ignore
these when classifying the oil brand on an invoice.

| Code | Meaning |
|------|---------|
| `GF6` | API SN / ILSAC GF-6A certification |
| `DEXOS1` | GM Dexos 1 approved |
| `AFC` | Manufacturer approved fluid |
| `VMATF` | Manufacturer approved transmission fluid |

### Service Tier Codes (`service_tier`)

These indicate the service package. Each invoice has exactly one. **Not
used for oil brand classification** but useful for understanding service
mix and pricing tiers.

| Code | Service Level |
|------|--------------|
| `CK` | Service Checklist (appears on virtually every invoice) |
| `S1` | Full Service — Conventional |
| `S2` | Full Service — High Mileage |
| `S3` | Full Service — Premium |
| `S4` | Full Service — Bottled |
| `S5` | Full Service — Synthetic |
| `S6` | Full Service — CAM2 Synthetic |
| `B7` | Full Service — High (Valvoline MaxLife tier) |
| `B8` | Full Service |
| `B9` | Full Service |
| `B10` | Full Service — CAM2 |

### Ancillary Codes (Ignore for Oil Analysis)

| Pattern | Category | Examples |
|---------|----------|----------|
| `OF*`, `CF*` | Oil/cartridge filter | OF2222, CF5436 |
| `AF*`, `WAF*` | Air filter | AF1480, WAF10032 |
| `C*` (5-digit), `CAF*` | Cabin air filter | C38224, CAF10059 |
| `FB`, `FV`, `FN` | Air freshener | Black Ice, Vanilla, New Car |
| `L*` (wiper), `R10-1` | Wiper blade | L22, L28, R10-1 |
| Digit-only (2–4 chars) | Parts (bulbs, wipers by size) | 22, 3157, 912 |
| `TOP6` | Coolant top-off | Antifreeze/coolant |
| `ATS3`, `VP094` | Transmission flush | T-Tech, VPO94 |
| `LAB` | Labor charge | Misc labor |
| `MIS5`, `MIS10` | Upcharge | Special filter/upcharge |
| `MT-35` | Battery | Interstate battery |
| `COF` | Customer filter | Customer's own oil filter |
| `FC` | Free check | Free fluid check ($0) |
| `MCSPD` | Discount/promo | Marshall County Sheriffs |
| `DS`, `H11B` | Light bulb | Driver side, H11B |
| `L10130` | Additive | Lucas Synthetic Oil Stabilizer |
| `11599`, `11604` | Drain plug | Drain plug replacement |
| `5436CAP` | Filter cap | Oil filter cap |

---

## RP Conversion Opportunity Categories

When analyzing competitor invoices, group them by conversion difficulty:

| Target Segment | Competitor Codes | RP Replacement | Difficulty |
|---------------|------------------|----------------|------------|
| **Full Synthetic → RS** | `S*`, `VS*`, `M*`, `CS*`, `PS*`, `PU*` | RS0W20, RS5W30, etc. | Low — already buying premium |
| **High Mileage → HMX** | `VM*` | HMX0W20, HMX5W30, etc. | Low — same price tier |
| **Conventional → RS/HMX** | `5W30`, `5W20`, `V*`, `VB*`, `VE*`, `PB*` | Upsell to RS or HMX | Medium — price jump |

### Viscosity Crosswalk (RP SKU for Each Competitor)

| Customer's Current Oil | → Royal Purple Replacement |
|----------------------|---------------------------|
| Any `*0W20` | RS0W20 or HMX0W20 (based on mileage) |
| Any `*5W20` | RS5W20 or HMX5W20 |
| Any `*5W30` | RS5W30 or HMX5W30 |
| Any `*0W16` | RS0W16 |
| Any `*5W40` | RS5W40 |
| Any `*0W40` | RS0W40 |
| Diesel `*5W40` | RSD5W40 |
| Diesel `*15W40` | RSD15W40 |
