# Excel Schema Reference

## File Structure — Three Formats

### Format V1 / V2 — Multi-Tab (one sheet per store)
```
Workbook
├── [Store 1 Name]     ← one sheet per installer location
├── [Store 2 Name]
├── ...
└── Report Summary     ← aggregate of all locations (skip when parsing per-store)
```
- V1 = RP-filtered only (only Royal Purple operation codes)
- V2 = Full-code export (all brands — RP + competitor + ancillary)

### Format V3 — Combined Single Sheet
```
Workbook
└── || Combined Summary    ← single sheet with Location column
```
All rows are on one sheet. Each row includes a `Location` column identifying
the store. Contains all operation codes (full-code export).

**How to detect:** Check `wb.sheetnames`. If there's a single sheet with
"Combined" in the name (or only one sheet), it's V3. If multiple named
store sheets exist, it's V1/V2. To distinguish V1 from V2, scan for
non-RP codes like `S5W30`, `VS0W20`, `GF6`, `OF2222`, `FB`.

---

## Format V1/V2 — Sheet Column Layout

| Col Index | Column Name | Type | Notes |
|-----------|-------------|------|-------|
| 0 | Invoice Date | string | "January 02, 2026" format. `None` on totals row. |
| 1 | # of Invoices | int | Number of invoices for this row |
| 2 | # of Vehicles | int | Usually equals # of Invoices |
| 3 | Operation Code + Desc | string | e.g. "HMX5W30 - ROYAL PURPLE HIGH MILEAGE" |
| 4 | Vehicle: Year/Make | string | e.g. "2018 HYUNDAI" or "(none)" |
| 5 | Vehicle: Model | string | e.g. "SANTA FE" or "(none)" |
| 6 | Total Rev/Inv | float | Average revenue per invoice for this group |
| 7 | Total Rev | float | Total revenue for this row (col 1 × col 6) |

## Totals Row

Each sheet ends with a summary totals row where:
- Column 0 (Invoice Date) = `None`
- Column 1 = total invoice count
- Column 2 = total vehicle count
- Column 6 = average rev/invoice (float)
- Column 7 = total revenue

**Always skip rows where `row[0] is None`** when building the per-row product breakdown.
You can use the totals row to cross-check your calculations.

---

## Format V3 — Combined Sheet Column Layout

| Col Index | Column Name | Type | Notes |
|-----------|-------------|------|-------|
| 0 | Location | string | Store name, e.g. "Aurora Oil & Lube" |
| 1 | Invoice Date | string | "March 01, 2026" format |
| 2 | Invoice # | int | Unique invoice identifier — **key for deduplication** |
| 3 | Operation Code + Desc | string | e.g. "RS0W20 - ROYAL PURPLE HIGH" |
| 4 | Vehicle: Year | int/string | e.g. 2018 |
| 5 | Vehicle: Make | string | e.g. "HYUNDAI" |
| 6 | Vehicle: Model | string | e.g. "SANTA FE" |
| 7 | # of Invoices | int | Usually 1 |
| 8 | Total Rev | float | **Invoice-level total** (same on all rows for one Invoice #) |
| 9 | Total Rev/Inv | float | Same as Total Rev for single-invoice rows |
| 10 | # of Vehicles | int | Usually 1 |

### Critical: Revenue Deduplication in V3

Each invoice generates **multiple rows** — one per operation code on the
invoice. All rows sharing the same `Invoice #` have the **same** `Total Rev`
value (the total for the whole invoice, not per line item). You **must**
group by `Invoice #` and take the revenue once per invoice to avoid
double-counting.

```python
# Correct: group by Invoice #, take revenue once
invoices = {}
for row in rows[1:]:
    inv_num = row[2]  # Invoice #
    if inv_num not in invoices:
        invoices[inv_num] = {
            'location': row[0],
            'revenue': float(row[8] or 0),
            'codes': [],
        }
    code = (row[3] or '').split(' - ')[0].strip()
    if code:
        invoices[inv_num]['codes'].append(code)
```

### No Totals Row in V3

Unlike V1/V2, there is no totals row at the end of each store's data.
Calculate totals by aggregating the deduplicated invoice records.

---

```
"RS0W20 - ROYAL PURPLE HIGH"
 ^^^^^^^^^^^  ^^^^^^^^^^^^^^^^
 Code prefix  Product category name
```

### Product Code → Category Mapping

| Code Prefix | Category Label | Notes |
|-------------|---------------|-------|
| `RS0W20` | Royal Purple High | Most common; newer vehicles |
| `RS5W20` | Royal Purple High | |
| `RS5W30` | Royal Purple High | Very common; trucks/SUVs |
| `RS5W40` | Royal Purple High | Performance engines |
| `RS0W16` | Royal Purple | Newer Toyota/Honda spec |
| `RS0W40` | Royal Purple Advanced | High-performance |
| `HMX0W20` | High Mileage | 75k+ mile vehicles |
| `HMX5W20` | High Mileage | |
| `HMX5W30` | High Mileage | Trucks/SUVs high mileage |
| `RSD5W40` | Duralec Diesel | Diesel engines; premium price point |
| `RSD15W40` | Duralec Diesel | Heavy duty diesel |
| `11722` | RP Legacy | Generic RP code — no viscosity/formulation specified. Common at Duke locations. Flag as data quality issue in reports. |

**Top Product Logic:**
```python
def get_top_product_category(code):
    if not code:
        return 'Royal Purple High'
    if code.startswith('HMX'):
        return 'Royal Purple High Mileage'
    elif code.startswith('RSD'):
        return 'Royal Purple Duralec'
    elif code == '11722':
        return 'RP Legacy'
    else:
        return 'Royal Purple High'
```

## Python Parsing Template

```python
import openpyxl
import json

def parse_excel(filepath):
    wb = openpyxl.load_workbook(filepath)
    stores = []

    for sheet_name in wb.sheetnames:
        if sheet_name == 'Report Summary':
            continue

        ws = wb[sheet_name]
        rows = list(ws.iter_rows(values_only=True))

        # Skip header row (index 0)
        product_rev = {}
        total_invoices = 0
        total_revenue = 0.0

        for row in rows[1:]:
            # Skip totals row (date is None)
            if row[0] is None:
                continue

            inv_date, num_inv, num_veh, op_code, veh_year, veh_model, rev_inv, rev = row

            if num_inv:
                total_invoices += num_inv
            if rev:
                total_revenue += rev
            if op_code:
                # Extract prefix code (everything before " - ")
                code = op_code.split(' - ')[0].strip()
                product_rev[code] = product_rev.get(code, 0) + (rev or 0)

        avg_rev = total_revenue / total_invoices if total_invoices > 0 else 0

        # Build sorted product breakdown
        product_breakdown = sorted(
            [{'code': k, 'revenue': round(v, 2)} for k, v in product_rev.items()],
            key=lambda x: -x['revenue']
        )

        # Determine top product category
        top_code = product_breakdown[0]['code'] if product_breakdown else ''
        if top_code.startswith('HMX'):
            top_product = 'Royal Purple High Mileage'
        elif top_code.startswith('RSD'):
            top_product = 'Royal Purple Duralec'
        else:
            top_product = 'Royal Purple High'

        stores.append({
            'name': sheet_name,
            'invoices': total_invoices,
            'totalRevenue': round(total_revenue, 2),
            'avgRevPerInvoice': round(avg_rev, 2),
            'topProduct': top_product,
            'productBreakdown': product_breakdown
        })

    return sorted(stores, key=lambda x: -x['totalRevenue'])
```

## Edge Cases

- **Multi-vehicle grouped rows**: When `# of Invoices > 1`, the `Total Rev/Inv` is an average. Always use `Total Rev` (col 7) for revenue totals.
- **`(none)` vehicle entries**: Normal — not all invoices have vehicle make/model captured. Include in calculations.
- **Very low revenue rows** (e.g., $5.89): These appear to be partial/adjustment transactions. Include as-is; don't filter them.
- **New stores mid-month**: Some stores have very few invoices (e.g., 9). This is expected for stores that joined the program late.
- **Duplicate operation codes on same date**: Multiple rows with same code/date means multiple customer groups — sum them.
