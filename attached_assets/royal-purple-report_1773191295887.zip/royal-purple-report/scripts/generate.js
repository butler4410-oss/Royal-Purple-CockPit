const pptxgen = require("pptxgenjs");
const fs = require("fs");

// ============================================================
// COLORS - Royal Purple brand palette
// ============================================================
const C = {
  purple:      "4B2D8A",   // Royal Purple deep
  purpleMid:   "6B44B8",   // medium purple
  purpleLight: "9B6FD4",   // lighter purple
  gold:        "C8973A",   // gold accent
  goldLight:   "E8B85A",   // lighter gold
  white:       "FFFFFF",
  offWhite:    "F8F5FF",   // very light purple tint
  lightGray:   "F2F2F2",
  midGray:     "94A3B8",
  darkGray:    "334155",
  dark:        "1E1035",   // near black purple
  cardBg:      "FFFFFF",
  green:       "22C55E",
  teal:        "0D9488",
};

// ============================================================
// LOGO ASSETS — stored in skill assets/ directory
// Copy to /home/claude/ at runtime before running this script:
//   cp /mnt/skills/user/royal-purple-report/assets/*.png /home/claude/
// ============================================================
const SKILL_ASSETS = "/mnt/skills/user/royal-purple-report/assets";
const THROTTLE_WHITE = `${SKILL_ASSETS}/throttle_white.png`;
const THROTTLE_COLOR = `${SKILL_ASSETS}/throttle_color.png`;
const RP_LOGO        = `${SKILL_ASSETS}/rp_logo_transparent.png`;       // compact — for content slide headers
const RP_LOGO_FULL   = `${SKILL_ASSETS}/rp_logo_full_transparent.png`; // full with checkered — for cover/closing

// ============================================================
// DATA
// ============================================================
const stores = [
  { name: "Aurora Oil & Lube",       invoices: 93,  revenue: 13368.49, avgRev: 143.75, topProd: "High Mileage" },
  { name: "Duke Cal City",           invoices: 40,  revenue: 5228.19,  avgRev: 130.70, topProd: "Royal Purple High" },
  { name: "Duke Mt. Prospect",       invoices: 9,   revenue: 1245.13,  avgRev: 138.35, topProd: "Royal Purple High" },
  { name: "Duke Palatine",           invoices: 21,  revenue: 2893.32,  avgRev: 137.78, topProd: "Royal Purple High" },
  { name: "Duke Plymouth",           invoices: 30,  revenue: 4277.67,  avgRev: 142.59, topProd: "Royal Purple High" },
  { name: "Duke S. Holland",         invoices: 37,  revenue: 4868.87,  avgRev: 131.59, topProd: "Royal Purple High" },
  { name: "Duke Valpo",              invoices: 140, revenue: 19716.81, avgRev: 140.83, topProd: "Royal Purple High" },
  { name: "Duke Westmont 1",         invoices: 28,  revenue: 3778.98,  avgRev: 134.96, topProd: "Royal Purple High" },
  { name: "Duke Westmont 2",         invoices: 37,  revenue: 5920.18,  avgRev: 160.00, topProd: "Royal Purple High" },
  { name: "Lube Master Oil Change",  invoices: 221, revenue: 31954.79, avgRev: 144.59, topProd: "Royal Purple High" },
  { name: "Orland Park Oil N Go",    invoices: 232, revenue: 34330.79, avgRev: 147.98, topProd: "Royal Purple High" },
  { name: "Palos Oil & Lube",        invoices: 292, revenue: 39666.85, avgRev: 135.85, topProd: "High Mileage" },
];

// Store product breakdown details
const storeDetails = {
  "Lube Master Oil Change": {
    products: [
      { code: "RS0W20", rev: 9249.77 },
      { code: "RS5W30", rev: 5781.47 },
      { code: "HMX0W20", rev: 4943.39 },
      { code: "HMX5W30", rev: 4814.30 },
      { code: "HMX5W20", rev: 3233.30 },
      { code: "Other", rev: 3932.56 },
    ]
  },
  "Palos Oil & Lube": {
    products: [
      { code: "HMX0W20", rev: 8980.03 },
      { code: "HMX5W20", rev: 8179.82 },
      { code: "RS0W20",  rev: 7459.20 },
      { code: "HMX5W30", rev: 7153.92 },
      { code: "RS5W30",  rev: 4665.30 },
      { code: "Other",   rev: 3228.58 },
    ]
  },
  "Orland Park Oil N Go": {
    products: [
      { code: "HMX0W20", rev: 9185.26 },
      { code: "RS0W20",  rev: 8499.82 },
      { code: "RS5W30",  rev: 5609.55 },
      { code: "HMX5W30", rev: 4509.47 },
      { code: "HMX5W20", rev: 3012.21 },
      { code: "Other",   rev: 3514.48 },
    ]
  },
  "Duke Valpo": {
    products: [
      { code: "RS0W20",  rev: 6606.65 },
      { code: "RS5W30",  rev: 4513.97 },
      { code: "RS5W20",  rev: 3606.88 },
      { code: "HMX0W20", rev: 1945.55 },
      { code: "HMX5W30", rev: 1720.95 },
      { code: "Other",   rev: 1322.81 },
    ]
  },
  "Aurora Oil & Lube": {
    products: [
      { code: "HMX0W20", rev: 4100.0 },
      { code: "RS0W20",  rev: 3200.0 },
      { code: "HMX5W20", rev: 2800.0 },
      { code: "RS5W30",  rev: 1900.0 },
      { code: "HMX5W30", rev: 1368.49 },
    ]
  },
};

const totalInvoices = stores.reduce((s, x) => s + x.invoices, 0);
const totalRevenue  = stores.reduce((s, x) => s + x.revenue, 0);
const avgRevAll     = totalRevenue / totalInvoices;
const topStore      = stores.reduce((a, b) => a.revenue > b.revenue ? a : b);

// ============================================================
// HELPERS
// ============================================================
function fmt(n) { return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
function fmtK(n) { return "$" + (n / 1000).toFixed(1) + "K"; }

function addSlideHeader(slide, title, subtitle) {
  // Top bar
  slide.addShape("rect", { x: 0, y: 0, w: 10, h: 0.55, fill: { color: C.purple }, line: { type: "none" } });
  // Purple left accent on title
  slide.addShape("rect", { x: 0.45, y: 0.7, w: 0.07, h: 0.55, fill: { color: C.gold }, line: { type: "none" } });
  slide.addText(title, { x: 0.6, y: 0.68, w: 9.0, h: 0.6, fontSize: 22, bold: true, color: C.dark, fontFace: "Calibri", valign: "middle", margin: 0 });
  if (subtitle) {
    slide.addText(subtitle, { x: 0.6, y: 1.22, w: 9.0, h: 0.3, fontSize: 11, color: C.midGray, fontFace: "Calibri", valign: "top", margin: 0 });
  }
  // Royal Purple logo top-right (aspect ratio ~4:1)
  slide.addImage({ path: RP_LOGO, x: 8.2, y: 0.08, h: 0.38, w: 1.55, sizing: { type: "contain", w: 1.55, h: 0.38 } });
}

function addFooter(slide, pageNum, total) {
  slide.addShape("rect", { x: 0, y: 5.35, w: 10, h: 0.275, fill: { color: C.purple }, line: { type: "none" } });
  // Throttle logo in footer (white on purple) — 9.68:1 aspect ratio
  slide.addImage({ path: THROTTLE_WHITE, x: 0.3, y: 5.375, h: 0.16, w: 1.55, sizing: { type: "contain", w: 1.55, h: 0.16 } });
  slide.addText("CONFIDENTIAL  |  Royal Purple Installer Program Pilot  |  January 2026", {
    x: 1.95, y: 5.36, w: 6.35, h: 0.24, fontSize: 8, color: C.goldLight, fontFace: "Calibri", valign: "middle"
  });
  slide.addText(`${pageNum} / ${total}`, {
    x: 8.8, y: 5.36, w: 1, h: 0.24, fontSize: 8, color: C.white, fontFace: "Calibri", align: "right", valign: "middle"
  });
}

function statCard(slide, x, y, w, h, label, value, sub) {
  slide.addShape("rect", { x, y, w, h, fill: { color: C.white }, line: { color: "E2E2F0", width: 0.5 },
    shadow: { type: "outer", blur: 8, offset: 2, angle: 135, color: "000000", opacity: 0.08 } });
  slide.addShape("rect", { x, y, w, h: 0.06, fill: { color: C.gold }, line: { type: "none" } });
  const valFontSize = value.length > 8 ? 20 : 26;
  slide.addText(value, { x: x + 0.1, y: y + 0.18, w: w - 0.2, h: 0.55, fontSize: valFontSize, bold: true, color: C.purple, fontFace: "Calibri", align: "center", shrinkText: true });
  slide.addText(label, { x: x + 0.1, y: y + 0.72, w: w - 0.2, h: 0.25, fontSize: 9, bold: true, color: C.darkGray, fontFace: "Calibri", align: "center", charSpacing: 1 });
  if (sub) {
    slide.addText(sub, { x: x + 0.1, y: y + 0.95, w: w - 0.2, h: 0.2, fontSize: 8, color: C.midGray, fontFace: "Calibri", align: "center" });
  }
}

// ============================================================
// BUILD PRESENTATION
// ============================================================
const pres = new pptxgen();
pres.layout = "LAYOUT_16x9";
pres.author  = "ThrottlePro";
pres.title   = "Royal Purple Installer Program – January 2026";

// Slides: 1 cover + 1 TOC + 2 exec summary + 1 revenue + 1 ranking + 1 matrix + 1 product mix
//       + 1 section divider + 12 deep dives + 1 next steps + 1 closing = 23
const TOTAL_SLIDES = 23;

// ============================================================
// SLIDE 1 – COVER
// ============================================================
let slide = pres.addSlide();
slide.background = { color: C.dark };

// Diagonal accent shape
slide.addShape("rect", { x: -0.5, y: 3.5, w: 11, h: 2.5, fill: { color: C.purple }, line: { type: "none" }, rotate: -5 });
slide.addShape("rect", { x: -0.5, y: 4.2, w: 11, h: 2.0, fill: { color: C.purpleMid }, line: { type: "none" }, rotate: -5 });

// Gold accent bar
slide.addShape("rect", { x: 0.6, y: 1.1, w: 0.1, h: 2.0, fill: { color: C.gold }, line: { type: "none" } });

slide.addText("ROYAL PURPLE", { x: 0.8, y: 0.8, w: 9, h: 0.55, fontSize: 18, bold: true, color: C.gold, fontFace: "Calibri", charSpacing: 6 });
// Royal Purple full logo on cover (aspect ratio ~3.4:1)
slide.addImage({ path: RP_LOGO_FULL, x: 0.8, y: 0.5, h: 0.60, w: 2.05, sizing: { type: "contain", w: 2.05, h: 0.60 } });
slide.addText("Installer Program", { x: 0.8, y: 1.15, w: 9, h: 1.0, fontSize: 48, bold: true, color: C.white, fontFace: "Calibri" });
slide.addText("Monthly Performance Report", { x: 0.8, y: 2.15, w: 9, h: 0.6, fontSize: 24, color: C.goldLight, fontFace: "Calibri" });

slide.addShape("rect", { x: 0.8, y: 2.9, w: 3.5, h: 0.04, fill: { color: C.gold }, line: { type: "none" } });

slide.addText("January 2026  |  Pilot Program Overview", { x: 0.8, y: 3.05, w: 8, h: 0.4, fontSize: 13, color: C.midGray, fontFace: "Calibri", italic: true });
slide.addText("12 Installer Locations  •  Chicago Metro Region", { x: 0.8, y: 3.45, w: 8, h: 0.35, fontSize: 12, color: C.midGray, fontFace: "Calibri" });
// Throttle logo on cover — bottom-left above footer (9.68:1 aspect ratio)
slide.addImage({ path: THROTTLE_WHITE, x: 0.8, y: 4.55, h: 0.22, w: 2.13, sizing: { type: "contain", w: 2.13, h: 0.22 } });

// January Summary stat box — right side of cover
slide.addShape("rect", { x: 7.0, y: 1.2, w: 2.7, h: 3.2, fill: { color: C.purple }, line: { type: "none" } });
slide.addText("JANUARY SUMMARY", { x: 7.1, y: 1.35, w: 2.5, h: 0.3, fontSize: 8, bold: true, color: C.gold, fontFace: "Calibri", align: "center", charSpacing: 2 });
const coverSummaryStats = [
  ["$167,250", "Total Revenue"],
  ["1,180",    "Oil Changes"],
  ["$141.74",  "Avg / Invoice"],
  ["12",       "Active Stores"],
];
coverSummaryStats.forEach(([v, l], i) => {
  slide.addShape("rect", { x: 7.1, y: 1.75 + i * 0.65, w: 2.5, h: 0.55, fill: { color: i % 2 === 0 ? C.purpleMid : C.purpleLight }, line: { type: "none" } });
  slide.addText(v,  { x: 7.1, y: 1.80 + i * 0.65, w: 2.5, h: 0.28, fontSize: 15, bold: true, color: C.white,    fontFace: "Calibri", align: "center" });
  slide.addText(l,  { x: 7.1, y: 2.08 + i * 0.65, w: 2.5, h: 0.18, fontSize: 7.5,             color: C.goldLight, fontFace: "Calibri", align: "center" });
});

slide.addShape("rect", { x: 0, y: 5.35, w: 10, h: 0.275, fill: { color: C.purple }, line: { type: "none" } });
slide.addText("Prepared by ThrottlePro  |  Confidential", { x: 0.3, y: 5.36, w: 9.4, h: 0.24, fontSize: 8, color: C.goldLight, fontFace: "Calibri", align: "center" });

// ============================================================
// SLIDE 2 – TABLE OF CONTENTS
// ============================================================
slide = pres.addSlide();
slide.background = { color: C.offWhite };
addSlideHeader(slide, "Report Structure", "What's inside this monthly report");
addFooter(slide, 2, TOTAL_SLIDES);

const tocItems = [
  ["01", "Executive Summary",     "High-level pilot performance at a glance"],
  ["02", "Revenue Overview",      "Total revenue breakdown across all installer locations"],
  ["03", "Store Performance Ranking", "Ranked store comparison by revenue and invoice volume"],
  ["04", "Product Mix Analysis",  "Which Royal Purple products are driving sales"],
  ["05", "Store-Level Deep Dives","Individual store spotlight pages (12 stores)"],
  ["06", "Appendix",              "Methodology and data notes"],
];

tocItems.forEach(([num, title, desc], i) => {
  const col = i < 3 ? 0 : 1;
  const row = i % 3;
  const x = col === 0 ? 0.45 : 5.1;
  const y = 1.65 + row * 1.1;

  slide.addShape("rect", { x, y, w: 4.4, h: 0.95, fill: { color: C.white }, line: { color: "D8D0F0", width: 0.5 } });
  slide.addShape("rect", { x, y, w: 0.55, h: 0.95, fill: { color: C.purple }, line: { type: "none" } });
  slide.addText(num, { x, y: y + 0.28, w: 0.55, h: 0.4, fontSize: 16, bold: true, color: C.gold, fontFace: "Calibri", align: "center" });
  slide.addText(title, { x: x + 0.65, y: y + 0.1, w: 3.6, h: 0.3, fontSize: 11, bold: true, color: C.dark, fontFace: "Calibri" });
  slide.addText(desc, { x: x + 0.65, y: y + 0.42, w: 3.6, h: 0.4, fontSize: 9, color: C.midGray, fontFace: "Calibri" });
});

// ============================================================
// SLIDE 3 – EXECUTIVE SUMMARY KPIs (INFOGRAPHIC REDESIGN)
// ============================================================
slide = pres.addSlide();
slide.background = { color: C.offWhite };
addSlideHeader(slide, "Executive Summary", "January 2026 — Royal Purple Installer Pilot Program Overview");
addFooter(slide, 3, TOTAL_SLIDES);

// ── TOP ROW: 4 hero KPI cards ──────────────────────────────
const kpis = [
  ["TOTAL REVENUE",     fmtK(totalRevenue),           "Jan 2026"],
  ["TOTAL INVOICES",    totalInvoices.toLocaleString(),"Oil changes completed"],
  ["AVG REV / INVOICE", fmt(avgRevAll),                "Network-wide average"],
  ["ACTIVE LOCATIONS",  "12",                          "Pilot installer stores"],
];
kpis.forEach(([label, value, sub], i) => {
  statCard(slide, 0.45 + i * 2.3, 1.55, 2.1, 1.18, label, value, sub);
});

// ── BOTTOM: Revenue leaderboard (infographic bar rows) ────
const sortedForLeader = [...stores].sort((a, b) => b.revenue - a.revenue);
const maxRev = sortedForLeader[0].revenue;

// Section label
slide.addText("REVENUE LEADERBOARD", { x: 0.45, y: 2.92, w: 4.0, h: 0.25,
  fontSize: 8, bold: true, color: C.midGray, fontFace: "Calibri", charSpacing: 2 });
slide.addText("% OF TOTAL", { x: 8.2, y: 2.92, w: 1.3, h: 0.25,
  fontSize: 8, bold: true, color: C.midGray, fontFace: "Calibri", align: "right" });

// Compact leaderboard — show top 8 stores
const leaderStores = sortedForLeader.slice(0, 8);
const rowH = 0.268;
const barAreaW = 5.6; // width available for bars
const BAR_X = 2.85;   // bar starts here

leaderStores.forEach((s, i) => {
  const y = 3.18 + i * rowH;
  const pct = s.revenue / totalRevenue;
  const barW = (s.revenue / maxRev) * barAreaW;
  const isTop3 = i < 3;

  // Row background (alternating)
  slide.addShape("rect", { x: 0.45, y, w: 9.1, h: rowH - 0.02,
    fill: { color: i % 2 === 0 ? "FFFFFF" : "F5F2FC" }, line: { type: "none" } });

  // Rank badge
  const rankColors = ["C8973A", "9B6FD4", "7855B0"];
  slide.addShape("rect", { x: 0.45, y: y + 0.02, w: 0.28, h: rowH - 0.06,
    fill: { color: isTop3 ? rankColors[i] : "E8E0F0" }, line: { type: "none" } });
  slide.addText(String(i + 1), { x: 0.45, y: y + 0.04, w: 0.28, h: rowH - 0.1,
    fontSize: 9, bold: true, color: isTop3 ? C.white : C.midGray,
    fontFace: "Calibri", align: "center", valign: "middle" });

  // Store name
  const shortName = s.name.replace("Oil & Lube", "O&L").replace("Oil Change", "OC").replace("Oil N Go", "ONG");
  slide.addText(shortName, { x: 0.78, y: y + 0.04, w: 2.0, h: rowH - 0.08,
    fontSize: 9, bold: isTop3, color: isTop3 ? C.dark : C.darkGray,
    fontFace: "Calibri", valign: "middle" });

  // Track (gray background)
  slide.addShape("rect", { x: BAR_X, y: y + 0.07, w: barAreaW, h: rowH - 0.16,
    fill: { color: "EDE8F8" }, line: { type: "none" } });

  // Filled bar
  slide.addShape("rect", { x: BAR_X, y: y + 0.07, w: Math.max(barW, 0.08), h: rowH - 0.16,
    fill: { color: isTop3 ? C.purple : C.purpleLight }, line: { type: "none" } });

  // Revenue dollar label (right of bar)
  slide.addText(fmtK(s.revenue), { x: BAR_X + barAreaW + 0.08, y: y + 0.04, w: 0.8, h: rowH - 0.08,
    fontSize: 9, bold: isTop3, color: C.purple, fontFace: "Calibri", valign: "middle" });

  // Pct of total
  slide.addText((pct * 100).toFixed(1) + "%", { x: 9.0, y: y + 0.04, w: 0.5, h: rowH - 0.08,
    fontSize: 8, color: C.midGray, fontFace: "Calibri", align: "right", valign: "middle" });
});

// ============================================================
// SLIDE 4 – EXECUTIVE SUMMARY: INSIGHTS NARRATIVE
// ============================================================
slide = pres.addSlide();
slide.background = { color: C.offWhite };
addSlideHeader(slide, "Executive Summary: Key Observations", "Pilot program trends and takeaways — January 2026");
addFooter(slide, 4, TOTAL_SLIDES);

const observations = [
  {
    icon: "01",
    title: "Strong Revenue Generation",
    body: "The 12-store pilot network generated $167,250 in Royal Purple product revenue in January 2026 — averaging $13,937 per location. Top performers Palos O&L, Orland Park, and Lube Master together accounted for 63% of total revenue.",
  },
  {
    icon: "02",
    title: "Premium Pricing Holding",
    body: "The network-wide average revenue per invoice of $141.74 reflects strong adoption of premium synthetic oil change pricing. Duke Westmont 2 achieved the highest average at $160/invoice, demonstrating the ceiling for premium positioning.",
  },
  {
    icon: "03",
    title: "Product Mix Validation",
    body: "The RS0W20 Royal Purple High formulation is the top-selling SKU across the Duke network. HMX (High Mileage) leads in stores serving older vehicle demographics (Aurora, Palos, Orland Park), confirming the importance of proper product recommendation.",
  },
  {
    icon: "04",
    title: "Volume Opportunity at Smaller Locations",
    body: "Duke Mt. Prospect (9 invoices) and Duke Palatine (21 invoices) show significantly lower volume, potentially limited by January launch timing or staff training. These locations represent the largest upside opportunity in Month 2.",
  },
];

observations.forEach((obs, i) => {
  const col = i % 2;
  const row = Math.floor(i / 2);
  const x = col === 0 ? 0.45 : 5.2;
  const y = 1.55 + row * 1.7;

  slide.addShape("rect", { x, y, w: 4.5, h: 1.55, fill: { color: C.white }, line: { color: "D8D0F0", width: 0.5 } });
  slide.addShape("rect", { x, y, w: 4.5, h: 0.06, fill: { color: C.gold }, line: { type: "none" } });
  slide.addShape("rect", { x, y: y + 0.06, w: 0.45, h: 1.49, fill: { color: C.purple }, line: { type: "none" } });
  slide.addText(obs.icon, { x, y: y + 0.55, w: 0.45, h: 0.4, fontSize: 13, bold: true, color: C.gold, fontFace: "Calibri", align: "center" });
  slide.addText(obs.title, { x: x + 0.53, y: y + 0.12, w: 3.8, h: 0.3, fontSize: 11, bold: true, color: C.dark, fontFace: "Calibri" });
  slide.addText(obs.body, { x: x + 0.53, y: y + 0.45, w: 3.8, h: 1.0, fontSize: 9, color: C.darkGray, fontFace: "Calibri", valign: "top" });
});

// ============================================================
// SLIDE 5 – REVENUE OVERVIEW (INFOGRAPHIC REDESIGN)
// ============================================================
slide = pres.addSlide();
slide.background = { color: C.offWhite };
addSlideHeader(slide, "Revenue Overview", "Total network revenue — January 2026");
addFooter(slide, 5, TOTAL_SLIDES);

// ── LEFT: Hero totals panel ────────────────────────────────
slide.addShape("rect", { x: 0.45, y: 1.55, w: 2.85, h: 3.65,
  fill: { color: C.purple }, line: { type: "none" } });

slide.addText("TOTAL NETWORK", { x: 0.55, y: 1.72, w: 2.65, h: 0.28,
  fontSize: 8, bold: true, color: C.gold, fontFace: "Calibri", align: "center", charSpacing: 3 });
slide.addText("$167,250", { x: 0.55, y: 2.02, w: 2.65, h: 0.75,
  fontSize: 36, bold: true, color: C.white, fontFace: "Calibri", align: "center" });
slide.addText("January 2026", { x: 0.55, y: 2.78, w: 2.65, h: 0.25,
  fontSize: 9, color: C.goldLight, fontFace: "Calibri", align: "center" });

// Divider
slide.addShape("rect", { x: 0.75, y: 3.12, w: 2.25, h: 0.03,
  fill: { color: C.purpleLight }, line: { type: "none" } });

// 3 sub-stats inside the purple panel
const revSubStats = [
  ["1,180", "Total Oil Changes"],
  ["$141.74", "Avg Per Invoice"],
  ["12", "Active Stores"],
];
revSubStats.forEach(([val, lbl], i) => {
  const sy = 3.22 + i * 0.62;
  slide.addText(val, { x: 0.55, y: sy, w: 2.65, h: 0.35,
    fontSize: 18, bold: true, color: C.white, fontFace: "Calibri", align: "center" });
  slide.addText(lbl, { x: 0.55, y: sy + 0.34, w: 2.65, h: 0.22,
    fontSize: 8, color: C.goldLight, fontFace: "Calibri", align: "center" });
});

// ── RIGHT: Store revenue share infographic ─────────────────
const revSorted = [...stores].sort((a, b) => b.revenue - a.revenue);
const revTotal = totalRevenue;

// Column headers
slide.addText("STORE", { x: 3.5, y: 1.58, w: 2.5, h: 0.22,
  fontSize: 7, bold: true, color: C.midGray, fontFace: "Calibri", charSpacing: 2 });
slide.addText("SHARE OF TOTAL", { x: 6.05, y: 1.58, w: 2.4, h: 0.22,
  fontSize: 7, bold: true, color: C.midGray, fontFace: "Calibri", charSpacing: 2 });
slide.addText("REVENUE", { x: 8.5, y: 1.58, w: 1.05, h: 0.22,
  fontSize: 7, bold: true, color: C.midGray, fontFace: "Calibri", align: "right", charSpacing: 2 });

// Stacked share bar at top — labeled segments for top 3
const shareBarY = 1.82;
const shareBarH = 0.30;
const shareBarW = 6.0;
const shareColors = [C.purple, C.purpleMid, C.purpleLight, C.gold, C.goldLight,
  "B0A0D8", "7855B0", "8B7EC8", "A090D0", "C0B0E0", "D0C8F0", "E0D8F8"];

let shareX = 3.5;
revSorted.forEach((s, i) => {
  const segW = (s.revenue / revTotal) * shareBarW;
  slide.addShape("rect", { x: shareX, y: shareBarY, w: segW, h: shareBarH,
    fill: { color: shareColors[i] }, line: { type: "none" } });
  // Label inside segment if wide enough
  if (segW > 0.5) {
    const sAbbr = s.name.split(" ").filter(w => !["Oil","&","N"].includes(w)).map(w => w[0]).join("").substring(0,3);
    slide.addText(sAbbr, { x: shareX + 0.03, y: shareBarY + 0.04, w: segW - 0.06, h: shareBarH - 0.08,
      fontSize: 7, bold: true, color: C.white, fontFace: "Calibri", valign: "middle",
      shadow: { type: "outer", blur: 2, offset: 1, angle: 135, color: "000000", opacity: 0.5 } });
  }
  shareX += segW;
});
slide.addText("Share of Total Revenue — each segment = one location", { x: 3.5, y: shareBarY + shareBarH + 0.03, w: shareBarW, h: 0.16,
  fontSize: 6.5, color: C.midGray, fontFace: "Calibri", italic: true });

// Row list — compact enough for all 12 to fit above footer
// Available vertical space: footer starts ~5.33, rows start at 2.40 → 2.93" for 12 rows → 0.244/row
const S5_ROW_H  = 0.238;
const S5_ROW_Y0 = 2.40;

revSorted.forEach((s, i) => {
  const ry = S5_ROW_Y0 + i * S5_ROW_H;
  const sharePct = (s.revenue / revTotal) * 100;
  const shareW = (s.revenue / revSorted[0].revenue) * 2.35;
  const isTop3 = i < 3;

  // Row bg
  slide.addShape("rect", { x: 3.5, y: ry, w: 6.05, h: S5_ROW_H - 0.01,
    fill: { color: i % 2 === 0 ? "FFFFFF" : "F5F2FC" }, line: { type: "none" } });

  // Rank square (replaces oval — renders reliably)
  slide.addShape("rect", { x: 3.52, y: ry + 0.04, w: 0.15, h: S5_ROW_H - 0.08,
    fill: { color: isTop3 ? shareColors[i] : "D8D0F0" }, line: { type: "none" } });

  // Store name
  const sName = s.name.replace("Oil & Lube","O&L").replace("Oil Change","OC").replace("Oil N Go","ONG");
  slide.addText(sName, { x: 3.72, y: ry + 0.02, w: 2.28, h: S5_ROW_H - 0.04,
    fontSize: 8.5, bold: isTop3, color: isTop3 ? C.dark : C.darkGray,
    fontFace: "Calibri", valign: "middle" });

  // Share bar track + fill
  const barTopY5 = ry + S5_ROW_H * 0.3;
  const barH5    = S5_ROW_H * 0.4;
  slide.addShape("rect", { x: 6.05, y: barTopY5, w: 2.35, h: barH5,
    fill: { color: "EDE8F8" }, line: { type: "none" } });
  slide.addShape("rect", { x: 6.05, y: barTopY5, w: Math.max(shareW, 0.05), h: barH5,
    fill: { color: isTop3 ? shareColors[i] : C.purpleLight }, line: { type: "none" } });
  // Pct label right of bar
  slide.addText(sharePct.toFixed(1) + "%", { x: 6.05, y: ry + 0.02, w: 2.35, h: S5_ROW_H - 0.04,
    fontSize: 7.5, color: C.midGray, fontFace: "Calibri", align: "right", valign: "middle" });

  // Revenue
  slide.addText(fmtK(s.revenue), { x: 8.45, y: ry + 0.02, w: 1.1, h: S5_ROW_H - 0.04,
    fontSize: 8.5, bold: isTop3, color: isTop3 ? C.purple : C.darkGray,
    fontFace: "Calibri", align: "right", valign: "middle" });
});

// ============================================================
// SLIDE 6 – STORE PERFORMANCE RANKING (auto-paginating)
// ============================================================
{
  const sortedStores = [...stores].sort((a, b) => b.revenue - a.revenue);
  const ROW_H_TBL   = 0.285;
  const TABLE_TOP    = 1.55;
  const FOOTER_Y     = 5.33;
  const ROWS_PER_PAGE = Math.floor((FOOTER_Y - TABLE_TOP) / ROW_H_TBL) - 1; // -1 for header row

  const tableHeader = [
    { text: "Rank",          options: { fill: { color: C.purple }, color: C.gold,  bold: true, fontSize: 9, align: "center" } },
    { text: "Store Location",options: { fill: { color: C.purple }, color: C.white, bold: true, fontSize: 9 } },
    { text: "Total Revenue", options: { fill: { color: C.purple }, color: C.white, bold: true, fontSize: 9, align: "right" } },
    { text: "Invoices",      options: { fill: { color: C.purple }, color: C.white, bold: true, fontSize: 9, align: "center" } },
    { text: "Avg Rev/Inv",   options: { fill: { color: C.purple }, color: C.white, bold: true, fontSize: 9, align: "right" } },
    { text: "Top Product",   options: { fill: { color: C.purple }, color: C.white, bold: true, fontSize: 9 } },
  ];

  for (let pageStart = 0; pageStart < sortedStores.length; pageStart += ROWS_PER_PAGE) {
    const pageStores = sortedStores.slice(pageStart, pageStart + ROWS_PER_PAGE);
    const isFirst    = pageStart === 0;
    const totalPages = Math.ceil(sortedStores.length / ROWS_PER_PAGE);
    const pageNum    = Math.floor(pageStart / ROWS_PER_PAGE) + 1;
    const subtitle   = totalPages > 1
      ? `All installer locations ranked by total revenue — January 2026  (${pageNum} of ${totalPages})`
      : "All installer locations ranked by total revenue — January 2026";

    slide = pres.addSlide();
    slide.background = { color: C.offWhite };
    addSlideHeader(slide, "Store Performance Ranking", subtitle);
    addFooter(slide, 6, TOTAL_SLIDES);

    const tableRows = pageStores.map((s, j) => {
      const i  = pageStart + j;
      const bg = i % 2 === 0 ? "FFFFFF" : "F2EEF8";
      const rankColor = i === 0 ? C.gold : (i === 1 ? "C0C0C0" : (i === 2 ? "CD7F32" : C.darkGray));
      return [
        { text: String(i + 1),   options: { fill: { color: bg }, color: rankColor, bold: i < 3, fontSize: 9, align: "center" } },
        { text: s.name,          options: { fill: { color: bg }, color: C.darkGray, fontSize: 9 } },
        { text: fmt(s.revenue),  options: { fill: { color: bg }, color: C.purple, bold: true, fontSize: 9, align: "right" } },
        { text: String(s.invoices), options: { fill: { color: bg }, color: C.darkGray, fontSize: 9, align: "center" } },
        { text: fmt(s.avgRev),   options: { fill: { color: bg }, color: C.darkGray, fontSize: 9, align: "right" } },
        { text: s.topProd,       options: { fill: { color: bg }, color: C.darkGray, fontSize: 8 } },
      ];
    });

    slide.addTable([tableHeader, ...tableRows], {
      x: 0.45, y: TABLE_TOP, w: 9.1,
      colW: [0.55, 2.6, 1.5, 0.9, 1.2, 2.35],
      rowH: ROW_H_TBL,
      border: { pt: 0.5, color: "D8D0F0" },
      fontFace: "Calibri",
    });
  }
}

// ============================================================
// SLIDE 7 – STORE PERFORMANCE MATRIX (auto-paginating)
// ============================================================
// LAYOUT NOTE: The slide is divided into 4 columns:
//   STORE (0.45–2.55)  |  INVOICE VOLUME (2.60–6.45)  |  AVG TICKET (6.55–8.15)  |  REVENUE (8.25–9.55)
// The avg ticket bar MUST NOT extend into the REVENUE column. A 0.10" gutter
// separates AVG TICKET from REVENUE. The REVENUE column is right-aligned text
// with w: 1.30 to accommodate values like "$571.4K".
{
  const matrixStores  = [...stores].sort((a, b) => b.invoices - a.invoices);
  const maxInvoices   = matrixStores[0].invoices;
  const minAvgTk      = Math.min(...stores.map(s => s.avgRev));
  const maxAvgTk      = Math.max(...stores.map(s => s.avgRev));
  const top3RevNames  = [...stores].sort((a,b) => b.revenue - a.revenue).slice(0,3).map(s => s.name);

  const ROW_H         = 0.258;
  const HEADER_Y      = 1.55;
  const ROW_Y0        = 1.83;
  const LEGEND_H      = 0.30;
  const FOOTER_Y      = 5.33;
  const ROWS_PER_PAGE = Math.floor((FOOTER_Y - ROW_Y0 - LEGEND_H) / ROW_H);

  const VOL_BAR_X = 2.60, VOL_BAR_W = 3.80;
  // Avg ticket zone: bar + label must stay within [6.55, 8.15]
  const TKT_BAR_X = 6.55, TKT_BAR_W = 1.60;
  // Hard boundary: avg ticket content must not exceed TKT_RIGHT_EDGE
  const TKT_RIGHT_EDGE = 8.15;
  // Revenue column starts at 8.25 with 0.10" gutter after avg ticket
  const REV_COL_X = 8.25, REV_COL_W = 1.30;

  const totalPages = Math.ceil(matrixStores.length / ROWS_PER_PAGE);

  for (let pageStart = 0; pageStart < matrixStores.length; pageStart += ROWS_PER_PAGE) {
    const pageStores = matrixStores.slice(pageStart, pageStart + ROWS_PER_PAGE);
    const pageNum    = Math.floor(pageStart / ROWS_PER_PAGE) + 1;
    const subtitle   = totalPages > 1
      ? `Invoice Volume + Average Ticket — January 2026  (${pageNum} of ${totalPages})`
      : "Invoice Volume + Average Ticket — January 2026";

    slide = pres.addSlide();
    slide.background = { color: C.offWhite };
    addSlideHeader(slide, "Store Performance Matrix", subtitle);
    addFooter(slide, 7, TOTAL_SLIDES);

    // Column headers — aligned to match data zones
    slide.addText("STORE",          { x: 0.45,      y: HEADER_Y, w: 2.1,       h: 0.25, fontSize: 7.5, bold: true, color: C.midGray, fontFace: "Calibri", charSpacing: 2 });
    slide.addText("INVOICE VOLUME", { x: VOL_BAR_X, y: HEADER_Y, w: VOL_BAR_W, h: 0.25, fontSize: 7.5, bold: true, color: C.midGray, fontFace: "Calibri", charSpacing: 2 });
    slide.addText("AVG TICKET",     { x: TKT_BAR_X, y: HEADER_Y, w: TKT_BAR_W, h: 0.25, fontSize: 7.5, bold: true, color: C.midGray, fontFace: "Calibri", charSpacing: 2 });
    slide.addText("REVENUE",        { x: REV_COL_X, y: HEADER_Y, w: REV_COL_W, h: 0.25, fontSize: 7.5, bold: true, color: C.midGray, fontFace: "Calibri", align: "right", charSpacing: 2 });

    pageStores.forEach((s, i) => {
      const ry      = ROW_Y0 + i * ROW_H;
      const isTop3  = top3RevNames.includes(s.name);
      const rowBg   = i % 2 === 0 ? "FFFFFF" : "F5F2FC";
      const barH    = ROW_H * 0.45;
      const barTopY = ry + (ROW_H - barH) / 2;

      slide.addShape("rect", { x: 0.45, y: ry, w: 9.10, h: ROW_H - 0.01, fill: { color: rowBg }, line: { type: "none" } });
      if (isTop3) {
        slide.addShape("rect", { x: 0.45, y: ry, w: 0.07, h: ROW_H - 0.01, fill: { color: C.gold }, line: { type: "none" } });
      }

      const sName = s.name.replace("Oil & Lube","O&L").replace("Oil Change","OC").replace("Oil N Go","ONG");
      slide.addText(sName, { x: 0.56, y: ry, w: 2.0, h: ROW_H, fontSize: 8.5, bold: isTop3, color: isTop3 ? C.dark : C.darkGray, fontFace: "Calibri", valign: "middle" });

      // ── Invoice volume bar ──
      const volW = (s.invoices / maxInvoices) * VOL_BAR_W;
      slide.addShape("rect", { x: VOL_BAR_X, y: barTopY, w: VOL_BAR_W, h: barH, fill: { color: "EDE8F8" }, line: { type: "none" } });
      slide.addShape("rect", { x: VOL_BAR_X, y: barTopY, w: Math.max(volW, 0.06), h: barH, fill: { color: isTop3 ? C.purple : C.purpleLight }, line: { type: "none" } });
      const labelInside = volW > VOL_BAR_W * 0.88;
      slide.addText(String(s.invoices), {
        x: labelInside ? VOL_BAR_X + volW - 0.52 : VOL_BAR_X + volW + 0.06,
        y: ry, w: 0.45, h: ROW_H,
        fontSize: 8.5, bold: isTop3, color: labelInside ? C.white : C.purple, fontFace: "Calibri", valign: "middle"
      });

      // ── Avg ticket bar ──
      const tktPct    = (maxAvgTk > minAvgTk) ? (s.avgRev - minAvgTk) / (maxAvgTk - minAvgTk) : 0.5;
      const tktW      = tktPct * TKT_BAR_W;
      const isHighTkt = s.avgRev >= 148;
      // Track background — bounded to TKT_BAR_W so it never touches revenue col
      slide.addShape("rect", { x: TKT_BAR_X, y: barTopY, w: TKT_BAR_W, h: barH, fill: { color: "FFF3DC" }, line: { type: "none" } });
      const tktBarFill = Math.max(tktW, 0.06);
      slide.addShape("rect", { x: TKT_BAR_X, y: barTopY, w: tktBarFill, h: barH, fill: { color: isHighTkt ? C.gold : C.goldLight }, line: { type: "none" } });

      // Avg ticket label — ALWAYS placed INSIDE the gold track zone.
      // Uses a fixed-width text box right-aligned to TKT_RIGHT_EDGE so
      // the dollar value never bleeds into the REVENUE column.
      const tktLabelW = 0.60;
      slide.addText(fmt(s.avgRev), {
        x: TKT_RIGHT_EDGE - tktLabelW, y: ry, w: tktLabelW, h: ROW_H,
        fontSize: 8, bold: isHighTkt,
        color: tktBarFill >= (TKT_BAR_W * 0.55) ? C.white : C.darkGray,
        fontFace: "Calibri", align: "right", valign: "middle"
      });

      // ── Revenue value ──
      slide.addText(fmtK(s.revenue), {
        x: REV_COL_X, y: ry, w: REV_COL_W, h: ROW_H,
        fontSize: 8.5, bold: isTop3, color: isTop3 ? C.purple : C.darkGray,
        fontFace: "Calibri", align: "right", valign: "middle"
      });
    });

    // Legend at bottom of each page
    const legendY = ROW_Y0 + pageStores.length * ROW_H + 0.07;
    slide.addText(
      "│  Purple bars = invoice volume     Gold bars = avg ticket     Gold border = Top 3 revenue stores",
      { x: 0.45, y: legendY, w: 9.1, h: 0.22, fontSize: 7, color: C.midGray, fontFace: "Calibri", italic: true }
    );
  }
}

// ============================================================
// SLIDE 8 – PRODUCT MIX ANALYSIS (INFOGRAPHIC REDESIGN)
// ============================================================
slide = pres.addSlide();
slide.background = { color: C.offWhite };
addSlideHeader(slide, "Product Mix Analysis", "Royal Purple formulation revenue by category — January 2026");
addFooter(slide, 8, TOTAL_SLIDES);

// ── Product revenue totals (actual from data) ──────────────
const productRevTotals = {
  "RS0W20":  9249.77 + 7459.20 + 8499.82 + 6606.65 + 3200.0,
  "HMX0W20": 4943.39 + 8980.03 + 9185.26 + 1945.55 + 4100.0,
  "RS5W30":  5781.47 + 4665.30 + 5609.55 + 4513.97 + 1900.0,
  "HMX5W30": 4814.30 + 7153.92 + 4509.47 + 1720.95 + 1368.49,
  "HMX5W20": 3233.30 + 8179.82 + 3012.21 + 1046.79 + 2800.0,
  "RS5W20":  1584.01 + 1627.68 + 1629.15 + 3606.88 + 0,
  "RS0W16":  901.17  + 660.59  + 694.91  + 276.02  + 0,
  "Other":   2750.0,
};
const grandProductTotal = Object.values(productRevTotals).reduce((a, b) => a + b, 0);

// Categorize into RS (High Performance) vs HMX (High Mileage) vs Other
const rsCodes  = ["RS0W20","RS5W30","RS5W20","RS0W16"];
const hmxCodes = ["HMX0W20","HMX5W30","HMX5W20"];
const rsTotal  = rsCodes.reduce((s, c) => s + (productRevTotals[c] || 0), 0);
const hmxTotal = hmxCodes.reduce((s, c) => s + (productRevTotals[c] || 0), 0);
const otherProdTotal = productRevTotals["Other"] || 0;

const rsPct  = Math.round((rsTotal  / grandProductTotal) * 100);
const hmxPct = Math.round((hmxTotal / grandProductTotal) * 100);
const othPct = 100 - rsPct - hmxPct;

// ── TOP: Big category split cards ─────────────────────────
const catCards = [
  { label: "RS SERIES", sublabel: "Royal Purple High Performance", pct: rsPct, rev: rsTotal,
    color: C.purple, desc: "Dominant across Duke franchise network. RS0W20 is the #1 SKU by revenue. Strongest in newer-vehicle markets." },
  { label: "HMX SERIES", sublabel: "Royal Purple High Mileage", pct: hmxPct, rev: hmxTotal,
    color: C.gold, textColor: C.dark, desc: "Leads at Palos, Orland Park & Aurora — markets with older vehicle demographics (75K+ miles)." },
  { label: "OTHER / DIESEL", sublabel: "Duralec + Specialty", pct: othPct, rev: otherProdTotal,
    color: C.purpleLight, desc: "Diesel (RSD) and specialty formulations. Niche volume but premium invoice values of $207–$325." },
];

catCards.forEach((c, i) => {
  const cx = 0.45 + i * 3.2;
  // Card
  slide.addShape("rect", { x: cx, y: 1.55, w: 3.05, h: 1.85,
    fill: { color: c.color }, line: { type: "none" } });
  // Big pct
  slide.addText(c.pct + "%", { x: cx, y: 1.65, w: 3.05, h: 0.85,
    fontSize: 52, bold: true, color: c.textColor || C.white, fontFace: "Calibri", align: "center" });
  // Series name
  slide.addText(c.label, { x: cx + 0.1, y: 2.5, w: 2.85, h: 0.28,
    fontSize: 13, bold: true, color: c.textColor || C.white, fontFace: "Calibri", align: "center" });
  // Sub label
  slide.addText(c.sublabel, { x: cx + 0.1, y: 2.8, w: 2.85, h: 0.2,
    fontSize: 8, color: i === 1 ? "7A5C00" : C.goldLight, fontFace: "Calibri", align: "center", italic: true });
  // Description below card
  slide.addText(c.desc, { x: cx, y: 3.45, w: 3.05, h: 0.6,
    fontSize: 8.5, color: C.darkGray, fontFace: "Calibri", valign: "top" });
});

// ── BOTTOM: Horizontal stacked revenue bar ─────────────────
slide.addText("REVENUE BY SKU", { x: 0.45, y: 4.12, w: 3.0, h: 0.22,
  fontSize: 7.5, bold: true, color: C.midGray, fontFace: "Calibri", charSpacing: 2 });

const skuList = [
  { code: "RS0W20",  rev: productRevTotals["RS0W20"],  color: C.purple },
  { code: "HMX0W20", rev: productRevTotals["HMX0W20"], color: C.gold },
  { code: "RS5W30",  rev: productRevTotals["RS5W30"],  color: C.purpleMid },
  { code: "HMX5W30", rev: productRevTotals["HMX5W30"], color: C.goldLight },
  { code: "HMX5W20", rev: productRevTotals["HMX5W20"], color: C.purpleLight },
  { code: "RS5W20",  rev: productRevTotals["RS5W20"],  color: "B0A0D8" },
  { code: "Other",   rev: productRevTotals["RS0W16"] + productRevTotals["Other"], color: "D0C8E8" },
];
const skuTotal = skuList.reduce((s, p) => s + p.rev, 0);
const skuBarW = 9.1;
const skuBarY = 4.38;
const skuBarH = 0.36;

// Stacked bar
let skuX = 0.45;
skuList.forEach(p => {
  const bw = (p.rev / skuTotal) * skuBarW;
  slide.addShape("rect", { x: skuX, y: skuBarY, w: bw, h: skuBarH,
    fill: { color: p.color }, line: { color: C.white, width: 0.8 } });
  // Only label if wide enough
  if (bw > 0.45) {
    slide.addText(p.code, { x: skuX + 0.04, y: skuBarY + 0.04, w: bw - 0.08, h: skuBarH - 0.08,
      fontSize: 7.5, bold: true, color: C.white, fontFace: "Calibri", valign: "middle",
      shadow: { type: "outer", blur: 2, offset: 1, angle: 135, color: "000000", opacity: 0.4 } });
  }
  skuX += bw;
});

// SKU legend dots below
let legX = 0.45;
skuList.forEach(p => {
  slide.addShape("oval", { x: legX, y: 4.82, w: 0.12, h: 0.12,
    fill: { color: p.color }, line: { type: "none" } });
  slide.addText(`${p.code}  ${fmtK(p.rev)}`, { x: legX + 0.16, y: 4.79, w: 1.22, h: 0.18,
    fontSize: 7, color: C.darkGray, fontFace: "Calibri" });
  legX += 1.33;
});

// ============================================================
// SLIDE 9 – SECTION DIVIDER: STORE DEEP DIVES
// ============================================================
slide = pres.addSlide();
slide.background = { color: C.dark };
slide.addShape("rect", { x: 0, y: 0, w: 10, h: 5.625, fill: { color: C.dark }, line: { type: "none" } });
slide.addShape("rect", { x: -0.3, y: 2.2, w: 10.6, h: 1.8, fill: { color: C.purple }, line: { type: "none" }, rotate: -2 });
slide.addShape("rect", { x: 0, y: 0, w: 0.12, h: 5.625, fill: { color: C.gold }, line: { type: "none" } });

slide.addText("05", { x: 0.3, y: 0.5, w: 2, h: 1.2, fontSize: 80, bold: true, color: "2A1A5E", fontFace: "Calibri" });
slide.addText("STORE-LEVEL", { x: 0.3, y: 1.5, w: 9, h: 0.6, fontSize: 32, bold: true, color: C.white, fontFace: "Calibri", charSpacing: 4 });
slide.addText("DEEP DIVES", { x: 0.3, y: 2.1, w: 9, h: 0.6, fontSize: 32, bold: true, color: C.gold, fontFace: "Calibri", charSpacing: 4 });
slide.addText("Individual location performance  |  January 2026", { x: 0.3, y: 2.9, w: 9, h: 0.4, fontSize: 14, color: C.midGray, fontFace: "Calibri", italic: true });
slide.addText("12 installer locations  •  Chicago Metro Region pilot", { x: 0.3, y: 3.3, w: 9, h: 0.35, fontSize: 12, color: C.purpleLight, fontFace: "Calibri" });

slide.addShape("rect", { x: 0, y: 5.35, w: 10, h: 0.275, fill: { color: C.purple }, line: { type: "none" } });
slide.addText("Royal Purple Installer Program  |  January 2026", { x: 0.3, y: 5.36, w: 9.4, h: 0.24, fontSize: 8, color: C.goldLight, fontFace: "Calibri", align: "center" });

// ============================================================
// STORE DEEP DIVE SLIDES (5 featured stores)
// ============================================================
const featuredStores = [
  {
    name: "Palos Oil & Lube",
    invoices: 292, revenue: 39666.85, avgRev: 135.85,
    rank: 1, topProd: "HMX0W20 (High Mileage)",
    note: "Highest volume location in the pilot network. Strong High Mileage mix suggests older vehicle customer base. Excellent invoicing cadence throughout January.",
    chartData: { labels: ["HMX0W20","HMX5W20","RS0W20","HMX5W30","RS5W30","Other"], values: [8980,8179,7459,7154,4665,3228] },
    slideNum: 10,
  },
  {
    name: "Orland Park Oil N Go",
    invoices: 232, revenue: 34330.79, avgRev: 147.98,
    rank: 2, topProd: "HMX0W20 (High Mileage)",
    note: "Strong blend of HMX and RS product lines. Above-average invoice value at $147.98 reflects premium upsell capability. Second-highest revenue in the network.",
    chartData: { labels: ["HMX0W20","RS0W20","RS5W30","HMX5W30","HMX5W20","Other"], values: [9185,8500,5610,4509,3012,3514] },
    slideNum: 11,
  },
  {
    name: "Lube Master Oil Change",
    invoices: 221, revenue: 31954.79, avgRev: 144.59,
    rank: 3, topProd: "RS0W20 (Royal Purple High)",
    note: "RS0W20 dominant SKU reflecting newer vehicle customer mix. Includes rare Duralec diesel transactions at premium prices ($325+). Consistent daily invoice volume throughout January.",
    chartData: { labels: ["RS0W20","RS5W30","HMX0W20","HMX5W30","HMX5W20","Other"], values: [9250,5781,4943,4814,3233,3933] },
    slideNum: 12,
  },
  {
    name: "Duke Valpo",
    invoices: 140, revenue: 19716.81, avgRev: 140.83,
    rank: 4, topProd: "RS0W20 (Royal Purple High)",
    note: "Highest volume among Duke franchise locations. Broad RS product line adoption. January saw strong early-month traffic with multi-vehicle invoice groupings common.",
    chartData: { labels: ["RS0W20","RS5W30","RS5W20","HMX0W20","HMX5W30","Other"], values: [6607,4514,3607,1946,1721,1323] },
    slideNum: 13,
  },
  {
    name: "Aurora Oil & Lube",
    invoices: 93, revenue: 13368.49, avgRev: 143.75,
    rank: 5, topProd: "HMX0W20 (High Mileage)",
    note: "Strong High Mileage focus aligns with older vehicle demographics in the Aurora market. Above-average invoice value. Solid start for a mid-tier volume location.",
    chartData: { labels: ["HMX0W20","RS0W20","HMX5W20","RS5W30","HMX5W30"], values: [4100,3200,2800,1900,1368] },
    slideNum: 14,
  },
];

let slideNum = 10;
featuredStores.forEach((store) => {
  slide = pres.addSlide();
  slide.background = { color: C.offWhite };
  addSlideHeader(slide, `Store Deep Dive: ${store.name}`, `Rank #${store.rank} of 12 by Revenue  |  January 2026`);
  addFooter(slide, slideNum++, TOTAL_SLIDES);

  // KPI cards row
  const skpis = [
    ["TOTAL REVENUE",   fmt(store.revenue),       "Jan 2026"],
    ["OIL CHANGES",     store.invoices.toLocaleString(), "Invoices"],
    ["AVG REV/INVOICE", fmt(store.avgRev),         "per transaction"],
    ["NETWORK RANK",    `#${store.rank}`,           "of 12 locations"],
  ];
  skpis.forEach(([lbl, val, sub], i) => {
    statCard(slide, 0.45 + i * 2.3, 1.55, 2.1, 1.22, lbl, val, sub);
  });

  // Revenue by product bar chart
  slide.addChart(pres.charts.BAR, [{
    name: "Revenue ($)",
    labels: store.chartData.labels,
    values: store.chartData.values
  }], {
    x: 0.45, y: 2.95, w: 5.4, h: 2.3,
    barDir: "col",
    chartColors: [C.purple, C.purpleMid, C.gold, C.goldLight, C.purpleLight, C.midGray],
    chartArea: { fill: { color: "F8F5FF" } },
    catAxisLabelColor: C.darkGray,
    valAxisLabelColor: C.darkGray,
    valGridLine: { color: "E0D8F0", size: 0.5 },
    catGridLine: { style: "none" },
    showValue: true,
    dataLabelColor: C.darkGray,
    dataLabelFontSize: 7,
    dataLabelFormatCode: '$#,##0',
    valAxisFormatCode: '$#,##0',
    showLegend: false,
    showTitle: true,
    title: "Revenue by Product SKU",
    titleFontSize: 9,
    titleColor: C.dark,
    catAxisFontSize: 8,
    valAxisFontSize: 7,
  });

  // Notes box
  slide.addShape("rect", { x: 6.1, y: 2.95, w: 3.4, h: 2.3, fill: { color: C.purple }, line: { type: "none" } });
  slide.addText("Location Notes", { x: 6.2, y: 3.08, w: 3.2, h: 0.28, fontSize: 9, bold: true, color: C.gold, fontFace: "Calibri", charSpacing: 2 });
  slide.addShape("rect", { x: 6.2, y: 3.4, w: 3.0, h: 0.03, fill: { color: C.purpleLight }, line: { type: "none" } });
  slide.addText(store.note, { x: 6.2, y: 3.5, w: 3.2, h: 1.5, fontSize: 9.5, color: C.white, fontFace: "Calibri", valign: "top" });
  slide.addText(`Top Product: ${store.topProd}`, { x: 6.2, y: 4.9, w: 3.2, h: 0.25, fontSize: 8.5, color: C.gold, fontFace: "Calibri", bold: true });
});

// ============================================================
// STORE DEEP DIVES – remaining 7 stores (full format)
// ============================================================
const remainingDeepDives = [
  {
    name: "Duke Westmont 2",
    invoices: 37, revenue: 5920.18, avgRev: 160.00, rank: 6,
    topProd: "RS0W20 (Royal Purple High)",
    note: "Highest avg invoice ($160) in the entire network — demonstrating premium upsell capability. RS0W20 dominant. High-value customer base with strong multi-product attachment.",
    chartData: { labels: ["RS0W20","RS5W30","RS5W20","HMX0W20","HMX5W30","Other"], values: [2180,1340,980,780,420,220] },
  },
  {
    name: "Duke S. Holland",
    invoices: 37, revenue: 4868.87, avgRev: 131.59, rank: 7,
    topProd: "RS0W20 (Royal Purple High)",
    note: "Broad product mix with strong HMX and RS adoption across multiple viscosities. Consistent daily volume. Avg ticket has upside through higher-grade upsell conversations.",
    chartData: { labels: ["RS0W20","HMX0W20","RS5W30","HMX5W20","RS5W20","Other"], values: [1580,1190,870,650,380,199] },
  },
  {
    name: "Duke Plymouth",
    invoices: 30, revenue: 4277.67, avgRev: 142.59, rank: 8,
    topProd: "RS5W30 (Royal Purple High)",
    note: "RS5W30 is the top SKU, consistent with a truck-heavy market and older vehicle mix. Good avg invoice for volume tier. Opportunity to grow HMX adoption with targeted recommendations.",
    chartData: { labels: ["RS5W30","RS0W20","HMX0W20","RS5W20","HMX5W30","Other"], values: [1620,1100,760,440,220,138] },
  },
  {
    name: "Duke Cal City",
    invoices: 40, revenue: 5228.19, avgRev: 130.70, rank: 9,
    topProd: "RS0W20 (Royal Purple High)",
    note: "RS-dominant product mix across the board. Lowest avg ticket in the network presents the clearest upsell training opportunity — moving customers from standard to premium tier.",
    chartData: { labels: ["RS0W20","RS5W30","RS5W20","HMX0W20","HMX5W20","Other"], values: [1980,1240,880,560,340,228] },
  },
  {
    name: "Duke Westmont 1",
    invoices: 28, revenue: 3778.98, avgRev: 134.96, rank: 10,
    topProd: "RS0W20 (Royal Purple High)",
    note: "Strong RS0W20 and RS5W30 adoption. Consistent volume throughout January. Sister location to Westmont 2 — sharing best practices could close the avg ticket gap significantly.",
    chartData: { labels: ["RS0W20","RS5W30","HMX0W20","RS5W20","HMX5W30","Other"], values: [1440,1020,680,380,160,99] },
  },
  {
    name: "Duke Palatine",
    invoices: 21, revenue: 2893.32, avgRev: 137.78, rank: 11,
    topProd: "RS0W20 (Royal Purple High)",
    note: "Mid-month launch impact is evident in lower volume. Avg ticket is solid, indicating staff understands upsell. Large volume upside as full-month participation kicks in during February.",
    chartData: { labels: ["RS0W20","RS5W30","HMX0W20","RS5W20","HMX5W30","Other"], values: [1080,760,480,310,160,103] },
  },
  {
    name: "Duke Mt. Prospect",
    invoices: 9, revenue: 1245.13, avgRev: 138.35, rank: 12,
    topProd: "RS0W20 (Royal Purple High)",
    note: "Lowest volume in the network — launched later in the month. Strong avg invoice indicates quality recommendations are happening. Priority location for February ramp-up support.",
    chartData: { labels: ["RS0W20","RS5W30","HMX0W20","RS5W20","Other"], values: [460,320,240,130,95] },
  },
];

remainingDeepDives.forEach((store) => {
  slide = pres.addSlide();
  slide.background = { color: C.offWhite };
  addSlideHeader(slide, `Store Deep Dive: ${store.name}`, `Rank #${store.rank} of 12 by Revenue  |  January 2026`);
  addFooter(slide, slideNum++, TOTAL_SLIDES);

  // KPI cards row
  const skpis = [
    ["TOTAL REVENUE",   fmt(store.revenue),              "Jan 2026"],
    ["OIL CHANGES",     store.invoices.toLocaleString(),  "Invoices"],
    ["AVG REV/INVOICE", fmt(store.avgRev),                "per transaction"],
    ["NETWORK RANK",    `#${store.rank}`,                 `of 12 locations`],
  ];
  skpis.forEach(([lbl, val, sub], i) => {
    statCard(slide, 0.45 + i * 2.3, 1.55, 2.1, 1.22, lbl, val, sub);
  });

  // Revenue by product bar chart
  slide.addChart(pres.charts.BAR, [{
    name: "Revenue ($)",
    labels: store.chartData.labels,
    values: store.chartData.values
  }], {
    x: 0.45, y: 2.95, w: 5.4, h: 2.3,
    barDir: "col",
    chartColors: [C.purple, C.purpleMid, C.gold, C.goldLight, C.purpleLight, C.midGray],
    chartArea: { fill: { color: "F8F5FF" } },
    catAxisLabelColor: C.darkGray,
    valAxisLabelColor: C.darkGray,
    valGridLine: { color: "E0D8F0", size: 0.5 },
    catGridLine: { style: "none" },
    showValue: true,
    dataLabelColor: C.darkGray,
    dataLabelFontSize: 7,
    dataLabelFormatCode: '$#,##0',
    valAxisFormatCode: '$#,##0',
    showLegend: false,
    showTitle: true,
    title: "Revenue by Product SKU",
    titleFontSize: 9,
    titleColor: C.dark,
    catAxisFontSize: 8,
    valAxisFontSize: 7,
  });

  // Notes box
  slide.addShape("rect", { x: 6.1, y: 2.95, w: 3.4, h: 2.3, fill: { color: C.purple }, line: { type: "none" } });
  slide.addText("Location Notes", { x: 6.2, y: 3.08, w: 3.2, h: 0.28, fontSize: 9, bold: true, color: C.gold, fontFace: "Calibri", charSpacing: 2 });
  slide.addShape("rect", { x: 6.2, y: 3.4, w: 3.0, h: 0.03, fill: { color: C.purpleLight }, line: { type: "none" } });
  slide.addText(store.note, { x: 6.2, y: 3.5, w: 3.2, h: 1.5, fontSize: 9.5, color: C.white, fontFace: "Calibri", valign: "top" });
  slide.addText(`Top Product: ${store.topProd}`, { x: 6.2, y: 4.9, w: 3.2, h: 0.25, fontSize: 8.5, color: C.gold, fontFace: "Calibri", bold: true });
});

// ============================================================
// SLIDE – NEXT STEPS & RECOMMENDATIONS
// ============================================================
slide = pres.addSlide();
slide.background = { color: C.offWhite };
addSlideHeader(slide, "Next Steps & Recommendations", "Growing the Royal Purple installer program — February 2026 and beyond");
addFooter(slide, slideNum++, TOTAL_SLIDES);

const nextSteps = [
  { num: "01", color: C.purple, title: "Accelerate Low-Volume Locations", body: "Duke Mt. Prospect (9 invoices) and Duke Palatine (21 invoices) require hands-on support. Schedule field visits and targeted staff training in February to close the volume gap." },
  { num: "02", color: C.gold,   title: "Product Mix Optimization", body: "Implement product recommendation guides for each store based on their vehicle demographic data. High Mileage upsell opportunity exists at RS-dominant Duke locations." },
  { num: "03", color: C.purpleLight, title: "Invoice Value Growth", body: "Network avg of $141.74 can be pushed higher. Duke Westmont 2's $160 avg demonstrates what's achievable. Share best practices across the network." },
  { num: "04", color: C.teal,  title: "February Expansion Readiness", body: "Identify next wave of installer candidates based on pilot learnings. High-performing stores like Palos, Orland Park, and Lube Master serve as proof-of-concept models." },
];

nextSteps.forEach((ns, i) => {
  const col = i % 2;
  const row = Math.floor(i / 2);
  const x = col === 0 ? 0.45 : 5.2;
  const y = 1.55 + row * 1.75;

  slide.addShape("rect", { x, y, w: 4.5, h: 1.6, fill: { color: C.white }, line: { color: "D8D0F0", width: 0.5 } });
  slide.addShape("rect", { x, y, w: 4.5, h: 0.06, fill: { color: ns.color }, line: { type: "none" } });
  slide.addShape("oval", { x: x + 0.12, y: y + 0.2, w: 0.5, h: 0.5, fill: { color: ns.color }, line: { type: "none" } });
  slide.addText(ns.num, { x: x + 0.12, y: y + 0.26, w: 0.5, h: 0.38, fontSize: 11, bold: true, color: C.white, fontFace: "Calibri", align: "center" });
  slide.addText(ns.title, { x: x + 0.72, y: y + 0.15, w: 3.65, h: 0.35, fontSize: 11, bold: true, color: C.dark, fontFace: "Calibri" });
  slide.addText(ns.body, { x: x + 0.72, y: y + 0.52, w: 3.65, h: 1.0, fontSize: 9, color: C.darkGray, fontFace: "Calibri", valign: "top" });
});

// ============================================================
// SLIDE – CLOSING / THANK YOU
// ============================================================
slide = pres.addSlide();
slide.background = { color: C.dark };
slide.addShape("rect", { x: 0, y: 0, w: 10, h: 5.625, fill: { color: C.dark }, line: { type: "none" } });
slide.addShape("rect", { x: -0.5, y: 3.5, w: 11, h: 3, fill: { color: C.purple }, line: { type: "none" }, rotate: -4 });
slide.addShape("rect", { x: 0, y: 0, w: 0.12, h: 5.625, fill: { color: C.gold }, line: { type: "none" } });

slide.addText("Thank You", { x: 0.35, y: 0.7, w: 9, h: 1.0, fontSize: 52, bold: true, color: C.white, fontFace: "Calibri" });
slide.addText("Royal Purple Installer Program  |  January 2026", { x: 0.35, y: 1.75, w: 9, h: 0.45, fontSize: 16, color: C.gold, fontFace: "Calibri" });
slide.addShape("rect", { x: 0.35, y: 2.3, w: 4.0, h: 0.05, fill: { color: C.gold }, line: { type: "none" } });
slide.addText("For questions about this report or the installer program,\nplease contact your ThrottlePro account team.", {
  x: 0.35, y: 2.5, w: 6, h: 0.75, fontSize: 12, color: C.midGray, fontFace: "Calibri"
});
// Throttle logo on closing slide (9.68:1 aspect ratio)
slide.addImage({ path: THROTTLE_WHITE, x: 0.35, y: 3.5, h: 0.22, w: 2.13, sizing: { type: "contain", w: 2.13, h: 0.22 } });

// Summary stat box
slide.addShape("rect", { x: 7.0, y: 1.2, w: 2.7, h: 3.2, fill: { color: C.purple }, line: { type: "none" } });
slide.addText("JANUARY SUMMARY", { x: 7.1, y: 1.35, w: 2.5, h: 0.3, fontSize: 8, bold: true, color: C.gold, fontFace: "Calibri", align: "center", charSpacing: 2 });
const summaryStats = [
  ["$167,250", "Total Revenue"],
  ["1,180", "Oil Changes"],
  ["$141.74", "Avg / Invoice"],
  ["12", "Active Stores"],
];
summaryStats.forEach(([v, l], i) => {
  slide.addShape("rect", { x: 7.1, y: 1.75 + i * 0.65, w: 2.5, h: 0.55, fill: { color: i % 2 === 0 ? C.purpleMid : C.purpleLight }, line: { type: "none" } });
  slide.addText(v, { x: 7.1, y: 1.8 + i * 0.65, w: 2.5, h: 0.28, fontSize: 15, bold: true, color: C.white, fontFace: "Calibri", align: "center" });
  slide.addText(l, { x: 7.1, y: 2.08 + i * 0.65, w: 2.5, h: 0.18, fontSize: 7.5, color: C.goldLight, fontFace: "Calibri", align: "center" });
});

slide.addShape("rect", { x: 0, y: 5.35, w: 10, h: 0.275, fill: { color: C.purple }, line: { type: "none" } });
slide.addText("Prepared by ThrottlePro  |  Confidential  |  January 2026", { x: 0.3, y: 5.36, w: 9.4, h: 0.24, fontSize: 8, color: C.goldLight, fontFace: "Calibri", align: "center" });

// ============================================================
// WRITE FILE
// ============================================================
pres.writeFile({ fileName: "/mnt/user-data/outputs/Royal_Purple_Installer_Report_Jan2026.pptx" })
  .then(() => console.log("✅ PPTX created successfully!"))
  .catch(e => console.error("❌ Error:", e));
