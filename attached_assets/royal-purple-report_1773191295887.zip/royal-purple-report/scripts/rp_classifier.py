"""
rp_classifier.py — Royal Purple vs Competitor invoice classifier

Parses a Duke of Oil full-invoice Excel export and classifies each
invoice by oil brand. Outputs a JSON summary with:
  - RP vs non-RP invoice counts, revenue, avg ticket
  - Competitor brand breakdown
  - Conversion opportunity analysis
  - Per-invoice detail for downstream reporting

Usage:
    python3 rp_classifier.py /path/to/export.xlsx [--output /path/to/output.json]

See references/operation-codes.md for the full code taxonomy.
"""

import openpyxl
import json
import sys
from collections import defaultdict

# ============================================================
# OPERATION CODE CLASSIFICATION
# ============================================================

# Royal Purple oil codes (known)
RP_OIL_CODES = {
    # RS Series (High Performance)
    'RS0W20', 'RS5W20', 'RS5W30', 'RS5W40', 'RS0W16', 'RS0W40',
    # HMX Series (High Mileage)
    'HMX0W20', 'HMX5W20', 'HMX5W30', 'RMS5W30', 'RMS5W20',
    # Duralec (Diesel)
    'RSD5W40', 'RSD15W40',
    # Generic / Legacy RP codes
    '11722',
    # RP Synthetic
    'RP0W20', 'RP5W30', 'RP5W20', 'RP0W16', 'RP5W40', 'RP0W40',
}

# Royal Purple additives (not oil, but still RP product revenue)
RP_ADDITIVE_CODES = {'18000', '11755'}

# All Royal Purple codes (oil + additives)
ALL_RP_CODES = RP_OIL_CODES | RP_ADDITIVE_CODES

# Competitor oil brand mapping: prefix → (brand_name, sub_brand)
# Order matters — more specific prefixes first
COMPETITOR_PREFIXES = [
    # CAM2
    ('S0W',   'CAM2', 'Synthetic'),
    ('S5W',   'CAM2', 'Synthetic'),
    # Valvoline
    ('VS',    'Valvoline', 'Full Synthetic'),
    ('VM',    'Valvoline', 'MaxLife'),
    ('VB',    'Valvoline', 'Conventional'),
    ('VE',    'Valvoline', 'Conventional'),
    ('V10W',  'Valvoline', 'Conventional'),
    ('V5W',   'Valvoline', 'Conventional'),
    # Mobil 1
    ('M0W',   'Mobil 1', 'Synthetic'),
    ('M5W',   'Mobil 1', 'Synthetic'),
    # Castrol
    ('CS',    'Castrol', 'Edge'),
    # Pennzoil
    ('PS',    'Pennzoil', 'Platinum'),
    ('PU',    'Pennzoil', 'Ultra'),
    ('PB',    'Pennzoil', 'Conventional'),
]

# Bare viscosity codes = CAM2 Conventional
CAM2_CONV_CODES = {'5W30', '5W20', '5W40', '10W30', '10W40'}

# Spec flags — NOT oil products, ignore for brand classification
SPEC_FLAGS = {'GF6', 'DEXOS1', 'AFC', 'VMATF'}

# Service tier codes — ignore for brand classification
SERVICE_TIERS = {'CK', 'S1', 'S2', 'S3', 'S4', 'S5', 'S6',
                 'B7', 'B8', 'B9', 'B10'}


def classify_code(code):
    """
    Classify a single operation code.

    Returns: (category, brand, sub_brand)
      category: 'rp_oil' | 'rp_additive' | 'competitor_oil' | 'spec_flag' |
                'service_tier' | 'ancillary'
      brand:     e.g. 'Royal Purple', 'CAM2', 'Valvoline', etc.
      sub_brand: e.g. 'RS Series', 'Synthetic', 'MaxLife', etc.
    """
    if code in RP_OIL_CODES:
        # Determine RP sub-brand
        if code.startswith('HMX') or code.startswith('RMS'):
            return ('rp_oil', 'Royal Purple', 'HMX Series')
        elif code.startswith('RSD'):
            return ('rp_oil', 'Royal Purple', 'Duralec')
        elif code.startswith('RP'):
            return ('rp_oil', 'Royal Purple', 'RP Synthetic')
        elif code == '11722':
            return ('rp_oil', 'Royal Purple', 'Generic RP')
        else:
            return ('rp_oil', 'Royal Purple', 'RS Series')

    if code in RP_ADDITIVE_CODES:
        return ('rp_additive', 'Royal Purple', 'Additive')

    # Check for unknown RP codes by prefix pattern
    if code.startswith('RS') and any(c.isdigit() for c in code):
        return ('rp_oil', 'Royal Purple', 'RS Series')
    if code.startswith('HMX') and any(c.isdigit() for c in code):
        return ('rp_oil', 'Royal Purple', 'HMX Series')
    if code.startswith('RMS') and any(c.isdigit() for c in code):
        return ('rp_oil', 'Royal Purple', 'HMX Series')
    if code.startswith('RSD') and any(c.isdigit() for c in code):
        return ('rp_oil', 'Royal Purple', 'Duralec')
    if code.startswith('RP') and any(c.isdigit() for c in code):
        return ('rp_oil', 'Royal Purple', 'RP Synthetic')

    if code in SPEC_FLAGS:
        return ('spec_flag', '', '')

    if code in SERVICE_TIERS:
        return ('service_tier', '', '')

    # Competitor oil by prefix
    for prefix, brand, sub in COMPETITOR_PREFIXES:
        if code.startswith(prefix):
            return ('competitor_oil', brand, sub)

    # Bare viscosity = CAM2 Conventional
    if code in CAM2_CONV_CODES:
        return ('competitor_oil', 'CAM2', 'Conventional')

    return ('ancillary', '', '')


def classify_invoice(codes):
    """
    Given a list of operation codes on one invoice, determine the oil brand.

    Returns: (brand, sub_brand, is_rp, conversion_segment)
      brand:       'Royal Purple', 'CAM2', 'Valvoline', etc.
      sub_brand:   'RS Series', 'Synthetic', 'MaxLife', etc.
      is_rp:       True if Royal Purple oil was used
      conversion_segment: 'current_rp' | 'full_syn' | 'high_mileage' |
                          'conventional' | 'unknown'
    """
    oil_brand = None
    oil_sub = None
    is_rp = False
    has_rp_additive = False

    for code in codes:
        cat, brand, sub = classify_code(code)
        if cat == 'rp_oil':
            oil_brand = brand
            oil_sub = sub
            is_rp = True
        elif cat == 'rp_additive':
            has_rp_additive = True
        elif cat == 'competitor_oil' and oil_brand is None:
            oil_brand = brand
            oil_sub = sub

    if oil_brand is None:
        oil_brand = 'Unknown'
        oil_sub = ''

    # Conversion segment
    if is_rp:
        segment = 'current_rp'
    elif oil_sub in ('Synthetic', 'Full Synthetic', 'Edge', 'Platinum', 'Ultra'):
        segment = 'full_syn'
    elif oil_sub in ('MaxLife',):
        segment = 'high_mileage'
    elif oil_sub in ('Conventional',):
        segment = 'conventional'
    else:
        segment = 'unknown'

    return (oil_brand, oil_sub, is_rp, segment, has_rp_additive)


def parse_workbook(filepath):
    """
    Parse a full-invoice Duke of Oil Excel export.

    Returns dict with complete analysis results.
    """
    wb = openpyxl.load_workbook(filepath)
    all_results = {}

    for sheet_name in wb.sheetnames:
        if sheet_name == 'Report Summary':
            continue

        ws = wb[sheet_name]
        rows = list(ws.iter_rows(values_only=True))
        if len(rows) < 2:
            continue

        # Detect column layout
        header = rows[0]
        # Find key column indices
        col_map = {}
        for i, h in enumerate(header):
            if h is None:
                continue
            hl = str(h).lower().strip()
            if hl == 'invoice date':
                col_map['date'] = i
            elif hl == 'invoice #':
                col_map['inv_num'] = i
            elif 'operation' in hl:
                col_map['op_code'] = i
            elif hl == '# of invoices':
                col_map['num_inv'] = i
            elif hl == 'total rev/inv':
                col_map['rev_inv'] = i
            elif hl == 'total rev':
                col_map['rev'] = i
            elif hl == '# of vehicles':
                col_map['vehicles'] = i
            elif 'model' in hl:
                col_map['model'] = i
            elif 'year' in hl:
                col_map['year'] = i
            elif 'make' in hl:
                col_map['make'] = i

        # Build invoice-level view
        invoices = {}
        for row in rows[1:]:
            if row[col_map.get('date', 0)] is None:
                continue  # skip totals row

            inv_num = row[col_map.get('inv_num', 1)]
            op_full = row[col_map.get('op_code', 2)] or ''
            code = op_full.split(' - ')[0].strip() if op_full else ''
            rev = row[col_map.get('rev', 7)] or 0

            if inv_num not in invoices:
                invoices[inv_num] = {
                    'date': str(row[col_map.get('date', 0)] or ''),
                    'codes': [],
                    'revenue': float(rev),
                    'year': row[col_map.get('year', 4)],
                    'make': row[col_map.get('make', 5)],
                    'model': row[col_map.get('model', 3)],
                }
            if code:
                invoices[inv_num]['codes'].append(code)

        # Classify each invoice
        brand_stats = defaultdict(lambda: {'count': 0, 'revenue': 0.0, 'invoices': []})
        segment_stats = defaultdict(lambda: {'count': 0, 'revenue': 0.0})
        rp_count = 0
        rp_revenue = 0.0
        rp_additive_count = 0
        non_rp_count = 0
        non_rp_revenue = 0.0
        total_count = len(invoices)
        total_revenue = 0.0

        for inv_num, data in invoices.items():
            brand, sub, is_rp, segment, has_additive = classify_invoice(data['codes'])
            rev = data['revenue']
            total_revenue += rev

            brand_key = f"{brand} — {sub}" if sub else brand
            brand_stats[brand_key]['count'] += 1
            brand_stats[brand_key]['revenue'] += rev

            segment_stats[segment]['count'] += 1
            segment_stats[segment]['revenue'] += rev

            if is_rp:
                rp_count += 1
                rp_revenue += rev
            else:
                non_rp_count += 1
                non_rp_revenue += rev

            if has_additive:
                rp_additive_count += 1

        rp_avg = rp_revenue / rp_count if rp_count > 0 else 0
        non_rp_avg = non_rp_revenue / non_rp_count if non_rp_count > 0 else 0

        # Date range
        dates = [d['date'] for d in invoices.values() if d['date']]
        date_range = f"{dates[0]} to {dates[-1]}" if dates else "unknown"

        all_results[sheet_name] = {
            'store_name': sheet_name,
            'date_range': date_range,
            'total_invoices': total_count,
            'total_revenue': round(total_revenue, 2),
            'rp_summary': {
                'invoices': rp_count,
                'revenue': round(rp_revenue, 2),
                'pct_invoices': round(rp_count / total_count * 100, 1) if total_count else 0,
                'pct_revenue': round(rp_revenue / total_revenue * 100, 1) if total_revenue else 0,
                'avg_ticket': round(rp_avg, 2),
            },
            'non_rp_summary': {
                'invoices': non_rp_count,
                'revenue': round(non_rp_revenue, 2),
                'pct_invoices': round(non_rp_count / total_count * 100, 1) if total_count else 0,
                'pct_revenue': round(non_rp_revenue / total_revenue * 100, 1) if total_revenue else 0,
                'avg_ticket': round(non_rp_avg, 2),
            },
            'rp_ticket_premium': round(rp_avg - non_rp_avg, 2),
            'rp_additive_attach_count': rp_additive_count,
            'brand_breakdown': {
                k: {
                    'count': v['count'],
                    'revenue': round(v['revenue'], 2),
                    'pct': round(v['count'] / total_count * 100, 1) if total_count else 0,
                    'avg_ticket': round(v['revenue'] / v['count'], 2) if v['count'] else 0,
                }
                for k, v in sorted(brand_stats.items(), key=lambda x: -x[1]['revenue'])
            },
            'conversion_segments': {
                k: {
                    'count': v['count'],
                    'revenue': round(v['revenue'], 2),
                    'pct': round(v['count'] / total_count * 100, 1) if total_count else 0,
                }
                for k, v in sorted(segment_stats.items(), key=lambda x: -x[1]['count'])
            },
        }

    return all_results


def print_summary(results):
    """Print a formatted console summary of the analysis."""
    for store_name, data in results.items():
        rp = data['rp_summary']
        non_rp = data['non_rp_summary']

        print(f"\n{'='*70}")
        print(f"  {store_name} — RP vs Non-RP Analysis")
        print(f"  {data['date_range']}")
        print(f"{'='*70}")
        print(f"  Total Invoices: {data['total_invoices']}   Total Revenue: ${data['total_revenue']:,.2f}")
        print()
        print(f"  {'':25} {'Invoices':>8} {'%':>7} {'Revenue':>12} {'%':>7} {'Avg Ticket':>10}")
        print(f"  {'-'*70}")
        print(f"  {'Royal Purple':<25} {rp['invoices']:>8} {rp['pct_invoices']:>6.1f}% ${rp['revenue']:>11,.2f} {rp['pct_revenue']:>6.1f}% ${rp['avg_ticket']:>9,.2f}")
        print(f"  {'Non-RP':<25} {non_rp['invoices']:>8} {non_rp['pct_invoices']:>6.1f}% ${non_rp['revenue']:>11,.2f} {non_rp['pct_revenue']:>6.1f}% ${non_rp['avg_ticket']:>9,.2f}")
        print(f"  RP Ticket Premium: ${data['rp_ticket_premium']:,.2f}")
        print()
        print(f"  BRAND BREAKDOWN:")
        for brand, stats in data['brand_breakdown'].items():
            print(f"    {brand:<30} {stats['count']:>4} inv ({stats['pct']:>5.1f}%)  ${stats['revenue']:>10,.2f}  avg ${stats['avg_ticket']:,.2f}")
        print()
        print(f"  CONVERSION SEGMENTS:")
        for seg, stats in data['conversion_segments'].items():
            print(f"    {seg:<20} {stats['count']:>4} invoices ({stats['pct']:>5.1f}%)  ${stats['revenue']:>10,.2f}")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python3 rp_classifier.py <excel_file> [--output <json_file>]")
        sys.exit(1)

    filepath = sys.argv[1]
    output_path = None
    if '--output' in sys.argv:
        idx = sys.argv.index('--output')
        if idx + 1 < len(sys.argv):
            output_path = sys.argv[idx + 1]

    results = parse_workbook(filepath)
    print_summary(results)

    if output_path:
        with open(output_path, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"\nJSON saved to {output_path}")
    else:
        default_out = '/home/claude/rp_analysis.json'
        with open(default_out, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"\nJSON saved to {default_out}")
