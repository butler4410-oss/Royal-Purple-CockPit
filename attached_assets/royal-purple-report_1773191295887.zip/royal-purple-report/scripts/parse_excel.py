#!/usr/bin/env python3
"""
Royal Purple Excel Report Parser
---------------------------------
Parses a Royal Purple installer program .xlsx report file and outputs
a JSON summary for use by the PPTX generator.

Usage:
    python3 parse_excel.py <path-to-xlsx> [output-path]

Output:
    JSON file at output-path (default: /home/claude/store_data.json)
    Also prints report month/year detected from the data.
"""

import openpyxl
import json
import sys
from datetime import datetime

def parse_date(date_str):
    """Parse 'January 02, 2026' format to datetime."""
    if not date_str:
        return None
    try:
        return datetime.strptime(str(date_str), "%B %d, %Y")
    except:
        return None

def get_top_product_category(code):
    """Map operation code prefix to friendly category name."""
    if not code:
        return "Royal Purple High"
    code = code.upper()
    if code.startswith("HMX"):
        return "Royal Purple High Mileage"
    elif code.startswith("RSD"):
        return "Royal Purple Duralec"
    else:
        return "Royal Purple High"

def parse_excel(filepath, output_path="/home/claude/store_data.json"):
    wb = openpyxl.load_workbook(filepath)

    stores = []
    all_dates = []

    for sheet_name in wb.sheetnames:
        if sheet_name == "Report Summary":
            continue

        ws = wb[sheet_name]
        rows = list(ws.iter_rows(values_only=True))

        if len(rows) < 2:
            continue

        # Skip header row
        product_rev = {}
        total_invoices = 0
        total_revenue = 0.0

        for row in rows[1:]:
            # Skip totals row (date column is None)
            if row[0] is None:
                continue

            try:
                inv_date = row[0]
                num_inv  = row[1] or 0
                num_veh  = row[2] or 0
                op_code  = row[3]
                rev      = row[7] or 0
            except IndexError:
                continue

            total_invoices += num_inv
            total_revenue  += rev

            # Track dates for month detection
            parsed = parse_date(str(inv_date)) if inv_date else None
            if parsed:
                all_dates.append(parsed)

            # Group revenue by operation code prefix
            if op_code:
                code = op_code.split(" - ")[0].strip()
                product_rev[code] = product_rev.get(code, 0) + rev

        if total_invoices == 0:
            continue

        avg_rev = total_revenue / total_invoices

        # Build sorted product breakdown (top 6 + "Other")
        sorted_products = sorted(
            [{"code": k, "revenue": round(v, 2)} for k, v in product_rev.items()],
            key=lambda x: -x["revenue"]
        )

        # Collapse tail into "Other" if more than 6 products
        if len(sorted_products) > 6:
            top5 = sorted_products[:5]
            other_rev = sum(p["revenue"] for p in sorted_products[5:])
            top5.append({"code": "Other", "revenue": round(other_rev, 2)})
            product_breakdown = top5
        else:
            product_breakdown = sorted_products

        # Determine top product
        top_code = sorted_products[0]["code"] if sorted_products else ""
        top_product = get_top_product_category(top_code)

        stores.append({
            "name": sheet_name,
            "invoices": total_invoices,
            "totalRevenue": round(total_revenue, 2),
            "avgRevPerInvoice": round(avg_rev, 2),
            "topProduct": top_product,
            "productBreakdown": product_breakdown
        })

    # Sort by revenue descending
    stores.sort(key=lambda x: -x["totalRevenue"])

    # Detect report month/year
    month_label = "Current Month"
    if all_dates:
        most_common_month = max(set(d.strftime("%B %Y") for d in all_dates),
                                key=lambda m: sum(1 for d in all_dates if d.strftime("%B %Y") == m))
        month_label = most_common_month

    output = {
        "monthLabel": month_label,
        "storeCount": len(stores),
        "stores": stores
    }

    with open(output_path, "w") as f:
        json.dump(output, f, indent=2)

    print(f"✅ Parsed {len(stores)} stores for {month_label}")
    print(f"   Total Revenue: ${sum(s['totalRevenue'] for s in stores):,.2f}")
    print(f"   Total Invoices: {sum(s['invoices'] for s in stores):,}")
    print(f"   Output: {output_path}")

    return output

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 parse_excel.py <xlsx-file> [output-json-path]")
        sys.exit(1)

    xlsx_path = sys.argv[1]
    out_path  = sys.argv[2] if len(sys.argv) > 2 else "/home/claude/store_data.json"

    parse_excel(xlsx_path, out_path)
