---
name: royal-purple-report
description: >
  Generates a professional Royal Purple Installer Program monthly PowerPoint
  report from an Excel data file. Use this skill whenever the user uploads or
  mentions a Royal Purple Excel report, installer program data, monthly store
  performance data, or asks to build a Royal Purple PPTX presentation.
  Always trigger this skill when the user provides a .xlsx file with store-level
  Royal Purple oil change data — even if they just say "make the report" or
  "build the presentation" without further context.
---

# Royal Purple Monthly Report Skill

Produces a polished, branded 23-slide PowerPoint presentation from a Royal
Purple installer program Excel report. The output matches the approved design
template: deep purple + gold palette, ThrottlePro branding, executive summary
first then store-level drill-downs.

## Brand Authority

This skill inherits core brand rules from the **matrix-brand-guide** skill.
For Matrix/Throttle master specs (colors, PMS/CMYK, typography, logo rules,
editorial standards), refer to the brand guide SKILL.md and
`references/visual-specs.md`. Logo assets live in the brand guide's `assets/`
directory. **Note:** Royal Purple uses its own purple + gold palette (not
Matrix navy + blue) for the report body, but Throttle branding still applies
to the footer, cover and closing slides per the brand guide.

This report is produced by **ThrottlePro** — an AI-driven customer retention
and acquisition platform for quick lube and auto service. ThrottlePro is
**not** a configurable CRM — it is a true Customer Data Platform (CDP) that
acts on customer behavior automatically. See the **Throttle Brand Context**
section below before customizing any copy or sales messaging in the report.

---

## Quick Start

1. **Read this file fully before writing any code.**
2. **Parse the Excel file** → see [references/excel-schema.md](references/excel-schema.md)
3. **Run the generator script** → see [scripts/generate.js](scripts/generate.js)
4. **QA visually** → convert to PDF, spot-check key slides

---

## Throttle Brand Context

The report footer, cover, and closing slides carry ThrottlePro branding.
Keep all copy consistent with these positioning pillars:

| Attribute | Value |
|-----------|-------|
| Company name | **ThrottlePro** (report branding) / **Throttle** (product name) |
| Tagline | **"More Cars. More Loyalty. Less Stress."** |
| Brand colors | Throttle Blue `#00AEEF` (UI), report uses Royal Purple palette |
| Positioning | AI-driven CDP for quick lube + auto service. Automated retention & acquisition. |
| Key differentiator | Built to **act** on customer data automatically — not configure and manage it |
| vs. Cinch | Throttle = automated intelligence. Cinch = manual configuration. |
| Capabilities | Lifecycle journeys, at-risk/lapsed detection, geofencing, direct mail + email + SMS, ROAS reporting |
| Audience | Quick lube operators, auto service franchises, multi-location groups |
| Proof points | Automated customer journeys, clear attribution, measurable ROAS, no ongoing config burden |

**Never position Throttle as a CRM.** It is a CDP with built-in AI automation.

---

## Inputs

| Input | Description |
|-------|-------------|
| `.xlsx` file | Royal Purple monthly report (one sheet per store + "Report Summary" sheet) |
| Month/year | Parsed from invoice dates in the data, or ask the user |

## Logo Assets

All logo files are stored in `assets/` within this skill directory and
referenced by the generator script at build time. **No session-dependent
paths** — logos persist across conversations.

| File | Usage | Placement |
|------|-------|-----------|
| `assets/rp_logo_transparent.png` | Compact RP logo (no checkered flag) | Content slide headers, top-right |
| `assets/rp_logo_full_transparent.png` | Full RP logo (checkered + SYNTHETIC OIL) | Cover slide, top-left |
| `assets/throttle_white.png` | Throttle wordmark (white on transparent) | Cover, closing, every footer bar |
| `assets/throttle_color.png` | Throttle wordmark (color on transparent) | Available for light backgrounds |

> **Throttle logo aspect ratio is 9.68:1** (600×62 px). Always size the
> bounding box to match this ratio to prevent stretching. Footer: `w: 1.55, h: 0.16`.
> Cover/Closing: `w: 2.13, h: 0.22`.

The generator script references these via:
```javascript
const SKILL_ASSETS = "/mnt/skills/user/royal-purple-report/assets";
const THROTTLE_WHITE = `${SKILL_ASSETS}/throttle_white.png`;
const RP_LOGO        = `${SKILL_ASSETS}/rp_logo_transparent.png`;
const RP_LOGO_FULL   = `${SKILL_ASSETS}/rp_logo_full_transparent.png`;
```

The Excel file comes in one of three formats. **Detect the format first**
before parsing — see [references/excel-schema.md](references/excel-schema.md)
for full column details and edge cases.

### Format V1 — RP-Filtered, Multi-Tab
- **One sheet per installer location** (e.g., "Aurora Oil & Lube", "Duke Valpo")
- **"Report Summary" sheet** — combined data across all locations
- Each sheet has columns: `Invoice Date`, `# of Invoices`, `# of Vehicles`, `Operation Code + Desc`, `Vehicle: Year/Make`, `Vehicle: Model`, `Total Rev/Inv`, `Total Rev`
- The final row of each sheet is a **totals row** with `null` in the date column
- Only contains Royal Purple operation codes

### Format V2 — Full-Code, Multi-Tab
- Same multi-tab structure as V1, but contains **ALL** operation codes (RP + competitor + ancillary)
- Detect by presence of non-RP oil codes like `S5W30`, `VS0W20`, `M5W20`, spec flags like `GF6`/`DEXOS1`, and ancillary codes like `OF2222`, `FB`
- **Must use `rp_classifier.py`** to separate RP vs non-RP invoices
- Revenue is per-invoice (duplicated across all line items for the same Invoice #) — **deduplicate by Invoice # to avoid double-counting**

### Format V3 — Full-Code, Combined Single Sheet
- **Single sheet** (e.g., "|| Combined Summary") with a `Location` column
- Columns: `Location`, `Invoice Date`, `Invoice #`, `Operation Code + Desc`, `Vehicle: Year`, `Vehicle: Make`, `Vehicle: Model`, `# of Invoices`, `Total Rev`, `Total Rev/Inv`, `# of Vehicles`
- Contains ALL operation codes — **must use RP classifier logic**
- Group by `Location` then by `Invoice #` to build invoice-level records
- Revenue is per-invoice (same value on every row sharing an Invoice #)

**How to detect the format:** Check `wb.sheetnames`. If there's a single
sheet with "Combined" in the name, it's V3. If multiple sheets exist and
you see non-RP codes (`S5W30`, `VS0W20`, `GF6`, `OF2222`, `FB`), it's V2.
Otherwise it's V1.

See [references/excel-schema.md](references/excel-schema.md) for full column details and edge cases.

---

## Output

A `.pptx` file saved to `/mnt/user-data/outputs/Royal_Purple_Installer_Report_[Mon][YYYY].pptx`

---

## Slide Structure (always in this order)

| # | Slide | Content |
|---|-------|---------|
| 1 | Cover | Branded title, month/year, store count, region + **January Summary stat box** (top-right) |
| 2 | Table of Contents | 6 sections with numbered cards |
| 3 | Executive Summary KPIs | 4 stat cards + revenue leaderboard (top 8 stores, ranked bars) |
| 4 | Executive Summary Observations | 4 narrative insight cards |
| 5 | Revenue Overview | Purple hero panel (left) + full store share-of-total list (right) |
| 6 | Store Performance Ranking | Full ranked table — **auto-paginating** if >12 stores |
| 7 | Store Performance Matrix | Dual-metric bar chart (volume + avg ticket) — **auto-paginating** |
| 8 | Product Mix Analysis | 3 category cards (RS/HMX/Other %) + stacked SKU revenue bar |
| 9 | Section Divider | "Store-Level Deep Dives" interstitial |
| 10–21 | Store Deep Dives | **All 12 stores** — one full slide each, ranked by revenue |
| 22 | Next Steps & Recommendations | 4 action cards |
| 23 | Closing / Thank You | Summary stats + contact info |

> **Critical rules:**
> - **Every store gets a full deep dive slide** — no "snapshot" tiles or 2-per-page condensed views
> - **Slides 6 and 7 auto-paginate** — if stores exceed page capacity, add continuation pages with "(1 of N)" subtitle
> - **January Summary stat box** appears on BOTH the cover (slide 1) AND the closing slide (slide 23)
> - Executive summary (slides 3–4) always precedes store-level detail (slides 10+)

---

## Design System

**Never deviate from these values** — they define the approved Royal Purple look.

```javascript
const C = {
  purple:      "4B2D8A",   // Primary brand purple
  purpleMid:   "6B44B8",   // Secondary purple
  purpleLight: "9B6FD4",   // Tertiary purple
  gold:        "C8973A",   // Primary accent / gold
  goldLight:   "E8B85A",   // Light gold
  white:       "FFFFFF",
  offWhite:    "F8F5FF",   // Slide background (purple-tinted)
  lightGray:   "F2F2F2",
  midGray:     "94A3B8",
  darkGray:    "334155",
  dark:        "1E1035",   // Near-black purple (cover/divider bg)
  green:       "22C55E",
  teal:        "0D9488",
};
```

**Typography:** Calibri throughout. Titles 22pt bold, body 9–11pt, stat callouts 20–26pt bold.

**Recurring elements:**
- Gold top-bar accent on every stat card (`h: 0.06`)
- Purple left-bar accent on slide headers (`w: 0.07`)
- Purple top bar on every slide (`h: 0.55`)
- "ROYAL PURPLE" gold text top-right on every content slide
- Purple footer bar every slide with page number

**Stat cards:** White background with gold top stripe, purple number, dark gray label, gray sub-label. Font size: 26pt for short values, 20pt for values >8 chars.

See [references/design-system.md](references/design-system.md) for complete component specs.

---

## Workflow

### Step 1 — Install dependencies

```bash
pip install openpyxl --break-system-packages -q
npm list -g pptxgenjs || npm install -g pptxgenjs
```

### Step 2 — Parse Excel data

Use Python + openpyxl to extract store data. For each sheet (excluding "Report Summary"):

```python
import openpyxl
wb = openpyxl.load_workbook('/mnt/user-data/uploads/YOUR_FILE.xlsx')

stores = {}
for sheet_name in wb.sheetnames:
    if sheet_name == 'Report Summary':
        continue
    ws = wb[sheet_name]
    rows = list(ws.iter_rows(values_only=True))
    # rows[0] = header, rows[1:] = data
    # Skip rows where rows[i][0] is None (totals row)
    ...
```

Build a JSON summary per store:
```json
{
  "name": "Palos Oil & Lube",
  "invoices": 292,
  "vehicles": 292,
  "totalRevenue": 39666.85,
  "avgRevPerInvoice": 135.85,
  "topProduct": "ROYAL PURPLE HIGH MILEAGE",
  "productBreakdown": [
    { "code": "HMX0W20", "revenue": 8980.03 },
    ...
  ]
}
```

Write extracted data to `/home/claude/store_data.json`.

See [references/excel-schema.md](references/excel-schema.md) for product code meanings and edge cases.

### Step 3 — Generate PPTX

Run the template generator, passing in the extracted JSON:

```bash
node /home/claude/generate_report.js /home/claude/store_data.json "January 2026"
```

The generator script template is at [scripts/generate.js](scripts/generate.js).
**Copy it to `/home/claude/generate_report.js` and modify for the current data.**

### Step 4 — QA

```bash
# Convert to PDF
python3 /mnt/skills/public/pptx/scripts/office/soffice.py --headless --convert-to pdf /mnt/user-data/outputs/Royal_Purple_Installer_Report_*.pptx

# Strip bookmarks from PDF (LibreOffice adds them by default)
python3 -c "
from pypdf import PdfReader, PdfWriter
reader = PdfReader('/home/claude/Royal_Purple_Installer_Report_*.pdf')
writer = PdfWriter()
for page in reader.pages:
    writer.add_page(page)
writer.remove_links()
with open('/mnt/user-data/outputs/Royal_Purple_Installer_Report_*.pdf', 'wb') as f:
    writer.write(f)
"

# Render slides as images
pdftoppm -jpeg -r 120 /mnt/user-data/outputs/Royal_Purple_Installer_Report_*.pdf slide

# Inspect cover, exec summary, ranking table, one deep dive, closing
```

Check for:
- Stat card values not overflowing (use `shrinkText: true` and adaptive font size)
- Footer page numbers correct
- All store names present in ranking table
- **Throttle logo not stretched** (should be 9.68:1 aspect ratio)
- Top 5 stores have full deep-dive slides

---

## Key Calculations

```
Total Revenue     = sum of all store totalRevenue
Total Invoices    = sum of all store invoices
Avg Rev/Invoice   = totalRevenue / totalInvoices
Top Store         = store with highest totalRevenue
Avg per Invoice   = store.totalRevenue / store.invoices

Product breakdown per store:
  - Group rows by Operation Code prefix (RS0W20, HMX5W30, etc.)
  - Sum Total Rev for each group
  - Sort descending by revenue
  - Top product = category name of highest-revenue group
    (HMX* = "High Mileage", RS* = "Royal Purple High", RSD* = "Duralec")
```

---

## Deep Dive Slide Requirements

**Every store gets a full deep-dive slide.** No store is relegated to a snapshot or summary tile.

Each deep dive slide contains:
1. **Slide header** — "Store Deep Dive: [Store Name]" + "Rank #N of [Total] by Revenue | [Month Year]"
2. **4 KPI stat cards** — Total Revenue, Oil Changes (invoices), Avg Rev/Invoice, Network Rank
3. **Bar chart** — Revenue by Product SKU (top 5-6 SKUs, purple/gold color scheme)
4. **Location Notes box** — Purple background, gold "Location Notes" label, white body text, gold "Top Product: [name]" footer
5. **Footer** — standard page number footer

Sort order for deep dives: **ranked by total revenue descending** (rank 1 = highest revenue).

For stores where per-SKU revenue data is unavailable, estimate from the store's total revenue
and known product mix (RS-dominant vs HMX-dominant based on customer demographics/notes).

---

## Auto-Pagination Rules

### Slide 6 — Store Performance Ranking Table
```
TABLE_TOP   = 1.55"
FOOTER_Y    = 5.33"
ROW_H       = 0.285"
ROWS_PER_PAGE = floor((FOOTER_Y - TABLE_TOP) / ROW_H) - 1  // subtract 1 for header
```
Loop over sorted stores in chunks of ROWS_PER_PAGE. Each page gets its own slide.
Subtitle format when paginating: `"...ranked by total revenue — [Month]  (1 of 2)"`

### Slide 7 — Store Performance Matrix
```
ROW_Y0      = 1.83"
LEGEND_H    = 0.30"
ROW_H       = 0.258"
ROWS_PER_PAGE = floor((5.33 - ROW_Y0 - LEGEND_H) / ROW_H)
```
Same loop pattern. Legend repeats on each page.

---

## Common Issues & Fixes

| Issue | Fix |
|-------|-----|
| Stat card value wrapping to 2 lines | Use `shrinkText: true`; set fontSize: `value.length > 8 ? 20 : 26` |
| PPTX won't open | Check for `#` in hex colors — strip all `#` prefixes |
| Shadow causing corrupt file | Never use 8-char hex for shadow color; use `opacity` property separately |
| Wrong page count in footer | Count slides before building; pass `TOTAL_SLIDES` constant |
| Product name is raw code | Map: `HMX*` → "High Mileage", `RS*` → "Royal Purple High", `RSD*` → "Duralec" |
| Rows overrunning footer | Calculate ROWS_PER_PAGE dynamically from FOOTER_Y − TABLE_TOP − header; never hardcode row count |
| `oval` shapes not rendering | PptxGenJS ovals do not render reliably in LibreOffice — use `rect` shapes instead |
| `scatter` / quadrant charts | PptxGenJS does not support native scatter; use custom `rect` bar rows instead |
| REVENUE column header stacking vertically | Give text box at least `w: 0.85` for the word "REVENUE" at 7.5pt with charSpacing |
| Avg ticket label overlapping REVENUE column (Slide 7) | Use fixed column zones: AVG TICKET ends at x=8.15, REVENUE starts at x=8.25 (0.10" gutter). Shrink `TKT_BAR_W` to 1.60 and place the dollar label in a fixed w=0.60 box right-aligned to `TKT_RIGHT_EDGE`. See `design-system.md → Store Performance Matrix`. |
| Volume bar label overlapping at max width | Check `volW > VOL_BAR_W * 0.88` — if true, render label inside bar in white |
| All-stores ranking table overflow | Use auto-paginating loop — never `addTable` with all rows in one call |
| Deep dive chart area font rendering | Set `catAxisFontSize: 8, valAxisFontSize: 7` explicitly; omit shadow objects entirely |
| Chart data labels missing $ sign | Add `dataLabelFormatCode: '$#,##0'` and `valAxisFormatCode: '$#,##0'` to all revenue bar chart options. See `design-system.md → Chart Styles`. |
| Throttle logo appears stretched/squished | Logo is 9.68:1 aspect ratio (600×62 px). Footer: `w: 1.55, h: 0.16`. Cover/closing: `w: 2.13, h: 0.22`. Always use `sizing: { type: "contain" }` with matching bounding box. |
| PDF has bookmarks/outlines panel | LibreOffice adds bookmarks by default. Strip with pypdf: `writer = PdfWriter(); [writer.add_page(p) for p in reader.pages]; writer.remove_links()` |
| Legacy code 11722 in product breakdown | Code 11722 is a generic RP code (no viscosity specified). Map to "RP Legacy" in charts. Flag in observations as a data quality issue — stores should use proper SKU codes. |
| Single combined sheet instead of per-store tabs | This is Format V3. Detect by checking `wb.sheetnames` for a single sheet with "Combined" in name. Group rows by `Location` column, then by `Invoice #`. See excel-schema.md. |
| Revenue double-counted in full-code exports | Full-code exports (V2/V3) repeat the invoice total on every line item row. Always deduplicate by `Invoice #` — take revenue once per invoice. |

---

## Reference Files

- [references/excel-schema.md](references/excel-schema.md) — Full Excel column spec, product code map, edge cases
- [references/design-system.md](references/design-system.md) — Component specs: stat cards, headers, footers, charts
- [references/operation-codes.md](references/operation-codes.md) — Complete operation code taxonomy (RP vs competitor vs ancillary)
- [scripts/generate.js](scripts/generate.js) — Full generator script template (copy + modify)
- [scripts/rp_classifier.py](scripts/rp_classifier.py) — RP vs Non-RP invoice classifier for full-code exports

---

## RP vs Non-RP Analysis (Full-Code Exports)

When the user uploads an Excel file with **ALL operation codes** (not just
Royal Purple-filtered data), use `rp_classifier.py` to determine RP
penetration rate and competitor brand share.

### How to Detect a Full-Code Export

A full-code export contains non-RP oil codes like `S5W30` (CAM2), `VS0W20`
(Valvoline), `M5W20` (Mobil 1), spec flags like `GF6` and `DEXOS1`, and
ancillary codes like `OF2222` (oil filters) and `FB` (air freshener). If
you see these codes, it's a full-code export — not an RP-only export.

### Running the Classifier

```bash
pip install openpyxl --break-system-packages -q
python3 /home/claude/rp_classifier.py /mnt/user-data/uploads/FILE.xlsx \
  --output /home/claude/rp_analysis.json
```

The classifier:
1. Groups rows by `Invoice #` to build invoice-level records
2. Identifies the **oil product code** on each invoice (ignoring spec flags,
   service tiers, filters, and ancillary items)
3. Classifies the oil as Royal Purple or a specific competitor brand
4. Assigns a **conversion segment**: `current_rp`, `full_syn`, `high_mileage`,
   `conventional`, or `unknown`
5. Outputs brand breakdown, RP vs non-RP summary, ticket premium, and
   conversion opportunity analysis

### Key Output Fields

| Field | Description |
|-------|-------------|
| `rp_summary.pct_invoices` | % of oil changes using Royal Purple |
| `rp_ticket_premium` | RP avg ticket minus non-RP avg ticket |
| `brand_breakdown` | Invoice count + revenue by competitor brand |
| `conversion_segments.full_syn` | Customers already buying synthetic — easiest RP targets |

### Code Taxonomy

See [references/operation-codes.md](references/operation-codes.md) for the
complete code-to-brand mapping, prefix rules for unknown codes, viscosity
crosswalk, and conversion opportunity categories.
